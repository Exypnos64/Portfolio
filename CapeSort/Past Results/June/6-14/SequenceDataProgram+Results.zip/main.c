#define _XOPEN_SOURCE
#include <sys/time.h>
#include <time.h>

#define SORT_NAME sorter
#define SORT_TYPE int
/* You can redefine the comparison operator.
   The default is
#define SORT_CMP(x, y)  ((x) < (y) ? -1 : ((x) == (y) ? 0 : 1))
   but the one below is often faster for integer types.
*/
#define SORT_CMP(x, y)(x - y)
#define MAX(x, y)(((x) > (y) ? (x) : (y)))
#define MIN(x, y)(((x) < (y) ? (x) : (y)))
#define SORT_CSWAP(x, y) { SORT_TYPE _sort_swap_temp = MAX((x), (y)); (x) = MIN((x), (y)); (y) = _sort_swap_temp; }
#include "sort.h"

/*
------------------------------------------------
*/
/*
	Copyright (C) 2014-2020 Igor van den Hoven ivdhoven@gmail.com
*/

/*
	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/*
	quadsort 1.1
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <math.h>


typedef int CMPFUNC(const void * a,
    const void * b);
/*
------------------------------------------------
*/
void verify(int * dst, const int size) {
    int i;

    for (i = 1; i < size; i++) {
        if (dst[i - 1] > dst[i]) {
            printf("Verify failed! at %d\n", i);
            /*
                  for (i = i - 2; i < SIZE; i++) {
                    printf(" %lld", (long long) dst[i]);
                  }
            */
            printf("\n");
            break;
        }
    }
}

void swap(int * a, int * b) {
    int temp;
    temp = * a;
    * a = * b;
    * b = temp;
}
/*
------------------------------------------------
*/
// benchmarking utilities

long long utime() {
    struct timeval now_time;

    gettimeofday( & now_time, NULL);

    return now_time.tv_sec * 1000000LL + now_time.tv_usec;
}
/*
------------------------------------------------
*/
//tim sort
float test_tim(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        sorter_tim_sort(z_array, max);
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    //printf("\e[0m  Tim Sort             : sorted %d elements in %f seconds. (%s)\n", max, total / 1000000.0, desc);
    return total / 1000000.0;
}
//selection sort
void test_selection(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        sorter_selection_sort(z_array, max);
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    printf("\e[0m  Selection Sort       : sorted %d elements in %f seconds. (%s)\n", max,
    		total / 1000000.0, desc);
}
//bubble sort
void test_bubble(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        sorter_bubble_sort(z_array, max);
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    printf("\e[0m  Bubble Sort          : sorted %d elements in %f seconds. (%s)\n", max,
    		total / 1000000.0, desc);
}
//bitonic sort
void test_bitonic(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        sorter_bitonic_sort(z_array, max);
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    printf("\e[0m  Bitonic Sort         : sorted %d elements in %f seconds. (%s)\n", max, total / 1000000.0, desc);
}
//merge sort
void test_merge(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        sorter_merge_sort(z_array, max);
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    printf("\e[0m  Merge Sort           : sorted %d elements in %f seconds. (%s)\n", max,
    		total / 1000000.0, desc);
}
//binary insertion
void test_binary_insertion(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        sorter_binary_insertion_sort(z_array, max);
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    printf("\e[0m  Binary Insertion Sort: sorted %d elements in %f seconds. (%s)\n", max,
    		total / 1000000.0, desc);
}
//heap sort
void test_heap(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        sorter_heap_sort(z_array, max);
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    printf("\e[0m  Heap Sort            : sorted %d elements in %f seconds. (%s)\n", max,
    		total / 1000000.0, desc);
}
//shell sort
void test_shell(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        sorter_shell_sort(z_array, max);
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    printf("\e[0m  Shell Sort           : sorted %d elements in %f seconds. (%s)\n", max,
    		total / 1000000.0, desc);
}
//in-place merge sort
void test_in_place_merge(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        sorter_merge_sort_in_place(z_array, max);
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    printf("\e[0m  In-place Merge Sort  : sorted %d elements in %f seconds. (%s)\n", max,
    		total / 1000000.0, desc);
}
//grail sort
void test_grail(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        sorter_grail_sort(z_array, max);
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    printf("\e[0m  Grail Sort           : sorted %d elements in %f seconds. (%s)\n", max,
    		total / 1000000.0, desc);
}
//sqrt sort
void test_sqrt(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        sorter_sqrt_sort(z_array, max);
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    printf("\e[0m  Sqrt Sort            : sorted %d elements in %f seconds. (%s)\n", max,
    		total / 1000000.0, desc);
}
//rec stable sort
void test_rec_stable(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        sorter_rec_stable_sort(z_array, max);
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    printf("\e[0m  Rec Stable Sort      : sorted %d elements in %f seconds. (%s)\n", max,
    		total / 1000000.0, desc);
}
//grail sort dyn buffer
void test_grail_dyn_buffer(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        sorter_grail_sort_dyn_buffer(z_array, max);
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    printf("\e[0m  Grail Dyn Buffer Sort: sorted %d elements in %f seconds. (%s)\n", max,
    		total / 1000000.0, desc);
}
//Shaker
//grail sort dyn buffer
void test_Shaker(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        //---------sharker sort-------------
        int i, j, k, m = max;
        for (i = 0; i < m;) {
            for (j = i + 1; j < m; j++) {
                if (z_array[j] < z_array[j - 1])
                    swap( & z_array[j], & z_array[j - 1]);
            }
            m--;
            for (k = m - 1; k > i; k--) {
                if (z_array[k] < z_array[k - 1])
                    swap( & z_array[k], & z_array[k - 1]);
            }
            i++;
        }
        //----------------------------------
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    printf("\e[0m  Shaker Sort          : sorted %d elements in %f seconds. (%s)\n", max,
    		total / 1000000.0, desc);
}
/*
------------------------------------------------
*/
void quarter_sort32(void * array, int key, size_t nmemb, CMPFUNC * cmp) {
    int * pta = array;

    switch (nmemb) {
    case 1:
        pta[1] = pta[0];
        pta[0] = key;
        return;
    case 2:
        pta[2] = pta[1];

        if (cmp( & key, & pta[0]) < 0) {
            pta[1] = pta[0];
            pta[0] = key;
        } else {
            pta[1] = key;
        }
        return;
    default:
        pta[3] = pta[2];

        if (cmp( & key, & pta[1]) < 0) {
            pta[2] = pta[1];

            if (cmp( & key, & pta[0]) < 0) {
                pta[1] = pta[0];
                pta[0] = key;
            } else {
                pta[1] = key;
            }
        } else {
            pta[2] = key;
        }
        return;
    }
}

void quarter_sort64(void * array, long long key, size_t nmemb, CMPFUNC * cmp) {
    long long * pta = array;

    switch (nmemb) {
    case 1:
        pta[1] = pta[0];
        pta[0] = key;
        return;
    case 2:
        pta[2] = pta[1];

        if (cmp( & key, & pta[0]) < 0) {
            pta[1] = pta[0];
            pta[0] = key;
        } else {
            pta[1] = key;
        }
        return;
    default:
        pta[3] = pta[2];

        if (cmp( & key, & pta[1]) < 0) {
            pta[2] = pta[1];

            if (cmp( & key, & pta[0]) < 0) {
                pta[1] = pta[0];
                pta[0] = key;
            } else {
                pta[1] = key;
            }
        } else {
            pta[2] = key;
        }
        return;
    }
}

void swap_sort32(void * array, size_t nmemb, CMPFUNC * cmp) {
    size_t offset;
    register int swap, * pta;

    pta = array;

    for (offset = 0; offset + 4 <= nmemb; offset += 4) {
        if (cmp( & pta[0], & pta[1]) > 0) {
            swap = pta[0];
            pta[0] = pta[1];
            pta[1] = swap;
        }

        if (cmp( & pta[1], & pta[2]) > 0) {
            if (cmp( & pta[0], & pta[2]) > 0) {
                swap = pta[2];
                pta[2] = pta[1];
                pta[1] = pta[0];
                pta[0] = swap;
            } else {
                swap = pta[2];
                pta[2] = pta[1];
                pta[1] = swap;
            }
        }

        if (cmp( & pta[2], & pta[3]) > 0) {
            if (cmp( & pta[0], & pta[3]) > 0) {
                swap = pta[3];
                pta[3] = pta[2];
                pta[2] = pta[1];
                pta[1] = pta[0];
                pta[0] = swap;
            } else if (cmp( & pta[1], & pta[3]) > 0) {
                swap = pta[3];
                pta[3] = pta[2];
                pta[2] = pta[1];
                pta[1] = swap;
            } else {
                swap = pta[3];
                pta[3] = pta[2];
                pta[2] = swap;
            }
        }

        pta += 4;
    }

    for (swap = 1; offset + swap < nmemb; swap++) {
        if (cmp( & pta[swap], & pta[swap - 1]) < 0) {
            quarter_sort32(pta, pta[swap], swap, cmp);
        }
    }
}

void swap_sort64(void * array, size_t nmemb, CMPFUNC * cmp) {
    size_t offset;
    register long long swap, * pta;

    pta = array;

    for (offset = 0; offset + 4 <= nmemb; offset += 4) {
        if (cmp( & pta[0], & pta[1]) > 0) {
            swap = pta[0];
            pta[0] = pta[1];
            pta[1] = swap;
        }

        if (cmp( & pta[1], & pta[2]) > 0) {
            if (cmp( & pta[0], & pta[2]) > 0) {
                swap = pta[2];
                pta[2] = pta[1];
                pta[1] = pta[0];
                pta[0] = swap;
            } else {
                swap = pta[2];
                pta[2] = pta[1];
                pta[1] = swap;
            }
        }

        if (cmp( & pta[2], & pta[3]) > 0) {
            if (cmp( & pta[0], & pta[3]) > 0) {
                swap = pta[3];
                pta[3] = pta[2];
                pta[2] = pta[1];
                pta[1] = pta[0];
                pta[0] = swap;
            } else if (cmp( & pta[1], & pta[3]) > 0) {
                swap = pta[3];
                pta[3] = pta[2];
                pta[2] = pta[1];
                pta[1] = swap;
            } else {
                swap = pta[3];
                pta[3] = pta[2];
                pta[2] = swap;
            }
        }

        pta += 4;
    }

    for (swap = 1; offset + swap < nmemb; swap++) {
        if (cmp( & pta[swap], & pta[swap - 1]) < 0) {
            quarter_sort64(pta, pta[swap], swap, cmp);
        }
    }
}

void quad_sort32(void * array, void * swap, size_t block, size_t nmemb, CMPFUNC * cmp) {
    size_t offset;
    register int * pta, * pts, * c, * c_max, * d, * d_max, * end;

    end = (int * ) array + nmemb;

    while (block < nmemb) {
        offset = 0;

        while (offset + block < nmemb) {
            pta = (int * ) array + offset;

            d_max = pta + block;

            if (cmp(d_max - 1, d_max) <= 0) {
                if (offset + block * 3 < nmemb) {
                    d_max = pta + block * 2;

                    if (cmp(d_max - 1, d_max) <= 0) {
                        d_max = offset + block * 4 <= nmemb ? pta + block * 3 : end;

                        if (cmp(d_max - 1, d_max) <= 0) {
                            offset += block * 4;
                            continue;
                        }
                    }
                } else if (offset + block * 2 < nmemb) {
                    d_max = offset + block * 2 <= nmemb ? pta + block * 2 : end;

                    if (cmp(d_max - 1, d_max) <= 0) {
                        offset += block * 4;
                        continue;
                    }
                } else {
                    offset += block * 4;
                    continue;
                }
            }

            pts = (int * ) swap;

            c = pta;
            c_max = pta + block;

            d = c_max;
            d_max = offset + block * 2 <= nmemb ? d + block : end;

            if (cmp(c_max - 1, d_max - 1) <= 0) {
                while (c < c_max) {
                    while (cmp(c, d) > 0) {
                        * pts++ = * d++;
                    }
                    * pts++ = * c++;
                }
                while (d < d_max)
                    *
                    pts++ = * d++;
            } else if (cmp(c, d_max - 1) > 0) {
                while (d < d_max)
                    *
                    pts++ = * d++;

                while (c < c_max)
                    *
                    pts++ = * c++;
            } else {
                while (d < d_max) {
                    while (cmp(c, d) <= 0) {
                        * pts++ = * c++;
                    }
                    * pts++ = * d++;
                }

                while (c < c_max) {
                    * pts++ = * c++;
                }
            }

            if (offset + block * 2 < nmemb) {
                c = pta + block * 2;

                if (offset + block * 3 < nmemb) {
                    c_max = c + block;
                    d = c_max;
                    d_max = offset + block * 4 <= nmemb ? d + block : end;

                    if (cmp(c_max - 1, d_max - 1) <= 0) {
                        while (c < c_max) {
                            while (cmp(c, d) > 0) {
                                * pts++ = * d++;
                            }
                            * pts++ = * c++;
                        }
                        while (d < d_max)
                            *
                            pts++ = * d++;
                    } else if (cmp(c, d_max - 1) > 0) {
                        while (d < d_max)
                            *
                            pts++ = * d++;
                        while (c < c_max)
                            *
                            pts++ = * c++;
                    } else {
                        while (d < d_max) {
                            while (cmp(c, d) <= 0) {
                                * pts++ = * c++;
                            }
                            * pts++ = * d++;
                        }
                        while (c < c_max)
                            *
                            pts++ = * c++;
                    }
                } else {
                    while (c < end)
                        *
                        pts++ = * c++;
                }
            }

            pts = (int * ) swap;

            c = pts;

            if (offset + block * 2 < nmemb) {
                c_max = c + block * 2;

                d = c_max;
                d_max = offset + block * 4 <= nmemb ? d + block * 2 : pts + nmemb - offset;

                if (cmp(c_max - 1, d_max - 1) <= 0) {
                    while (c < c_max) {
                        while (cmp(c, d) > 0) {
                            * pta++ = * d++;
                        }
                        * pta++ = * c++;
                    }
                    while (d < d_max)
                        *
                        pta++ = * d++;
                } else if (cmp(c, d_max - 1) > 0) {
                    while (d < d_max)
                        *
                        pta++ = * d++;
                    while (c < c_max)
                        *
                        pta++ = * c++;
                } else {
                    while (d < d_max) {
                        while (cmp(d, c) > 0) {
                            * pta++ = * c++;
                        }
                        * pta++ = * d++;
                    }
                    while (c < c_max)
                        *
                        pta++ = * c++;
                }
            } else {
                d_max = pts + nmemb - offset;

                while (c < d_max)
                    *
                    pta++ = * c++;
            }
            offset += block * 4;
        }
        block *= 4;
    }
}

void quad_sort64(void * array, void * swap, size_t block, size_t nmemb, CMPFUNC * cmp) {
    size_t offset;
    register long long * pta, * pts, * c, * c_max, * d, * d_max, * end;

    end = (long long * ) array + nmemb;

    while (block < nmemb) {
        offset = 0;

        while (offset + block < nmemb) {
            pta = (long long * ) array + offset;

            d_max = pta + block;

            if (cmp(d_max - 1, d_max) <= 0) {
                if (offset + block * 3 < nmemb) {
                    d_max = pta + block * 2;

                    if (cmp(d_max - 1, d_max) <= 0) {
                        d_max = offset + block * 4 <= nmemb ? pta + block * 3 : end;

                        if (cmp(d_max - 1, d_max) <= 0) {
                            offset += block * 4;
                            continue;
                        }
                    }
                } else if (offset + block * 2 < nmemb) {
                    d_max = offset + block * 2 <= nmemb ? pta + block * 2 : end;

                    if (cmp(d_max - 1, d_max) <= 0) {
                        offset += block * 4;
                        continue;
                    }
                } else {
                    offset += block * 4;
                    continue;
                }
            }

            pts = (long long * ) swap;

            c = pta;
            c_max = pta + block;

            d = c_max;
            d_max = offset + block * 2 <= nmemb ? d + block : end;

            if (cmp(c, d_max - 1) > 0) {
                while (d < d_max)
                    *
                    pts++ = * d++;

                while (c < c_max)
                    *
                    pts++ = * c++;
            } else {
                if (cmp(c_max - 1, d_max - 1) <= 0) {
                    while (c < c_max) {
                        while (cmp(c, d) > 0) {
                            * pts++ = * d++;
                        }
                        * pts++ = * c++;
                    }
                    while (d < d_max)
                        *
                        pts++ = * d++;
                } else {
                    while (d < d_max) {
                        while (cmp(c, d) <= 0) {
                            * pts++ = * c++;
                        }
                        * pts++ = * d++;
                    }

                    while (c < c_max) {
                        * pts++ = * c++;
                    }
                }
            }

            if (offset + block * 2 < nmemb) {
                c = pta + block * 2;

                if (offset + block * 3 < nmemb) {
                    c_max = c + block;
                    d = c_max;
                    d_max = offset + block * 4 <= nmemb ? d + block : end;

                    if (cmp(c, d_max - 1) > 0) {
                        while (d < d_max)
                            *
                            pts++ = * d++;
                        while (c < c_max)
                            *
                            pts++ = * c++;
                    } else {
                        if (cmp(c_max - 1, d_max - 1) <= 0) {
                            while (c < c_max) {
                                while (cmp(c, d) > 0) {
                                    * pts++ = * d++;
                                }
                                * pts++ = * c++;
                            }
                            while (d < d_max)
                                *
                                pts++ = * d++;
                        } else {
                            while (d < d_max) {
                                while (cmp(c, d) <= 0) {
                                    * pts++ = * c++;
                                }
                                * pts++ = * d++;
                            }
                            while (c < c_max)
                                *
                                pts++ = * c++;
                        }
                    }
                } else {
                    while (c < end)
                        *
                        pts++ = * c++;
                }
            }

            pts = (long long * ) swap;

            c = pts;

            if (offset + block * 2 < nmemb) {
                c_max = c + block * 2;

                d = c_max;
                d_max = offset + block * 4 <= nmemb ? d + block * 2 : pts + nmemb - offset;

                if (cmp(c, d_max - 1) > 0) {
                    while (d < d_max)
                        *
                        pta++ = * d++;
                    while (c < c_max)
                        *
                        pta++ = * c++;
                } else {
                    if (cmp(c_max - 1, d_max - 1) <= 0) {
                        while (c < c_max) {
                            while (cmp(c, d) > 0) {
                                * pta++ = * d++;
                            }
                            * pta++ = * c++;
                        }
                        while (d < d_max)
                            *
                            pta++ = * d++;
                    } else {
                        while (d < d_max) {
                            while (cmp(d, c) > 0) {
                                * pta++ = * c++;
                            }
                            * pta++ = * d++;
                        }
                        while (c < c_max)
                            *
                            pta++ = * c++;
                    }
                }

            } else {
                d_max = pts + nmemb - offset;

                while (c < d_max)
                    *
                    pta++ = * c++;
            }
            offset += block * 4;
        }
        block *= 4;
    }
}

void quadsort(void * array, size_t nmemb, size_t size, CMPFUNC * cmp) {
    void * swap;

    swap = malloc(nmemb * size);

    if (size == sizeof(int)) {
        swap_sort32(array, nmemb, cmp);

        quad_sort32(array, swap, 4, nmemb, cmp);
    } else if (size == sizeof(long long)) {
        swap_sort64(array, nmemb, cmp);

        quad_sort64(array, swap, 4, nmemb, cmp);
    }

    free(swap);
}

int cmp_int(const void * a,
    const void * b) {
    return *(int * ) a - * (int * ) b;
}

int cmp_str(const void * a,
    const void * b) {
    return strcmp( * (const char ** ) a, *(const char ** ) b);
}

float test_quad(int * z_array, int * r_array, int max, int rep, char * desc) {
    long long start, end, total, best;
    int cnt, sam, stp;

    best = 0;

    for (sam = 0; sam < 1; sam++) {
        total = 0;

        for (stp = 0; stp < rep; stp++) {
            memcpy(z_array, r_array, max * sizeof(int));

            if (sam == 0 && stp == 0 && max <= 10) printf("\e[1;31m%10d %10d %10d %10d %10d %10d %10d %10d %10d %10d\n", z_array[0], z_array[1], z_array[2], z_array[3], z_array[4], z_array[5], z_array[6], z_array[7], z_array[8], z_array[9]);

            start = utime();

            quadsort(z_array, max, sizeof(int), cmp_int);

            end = utime();

            if (sam == 0 && stp == 0 && max <= 10) printf("\e[1;32m%10d %10d %10d %10d %10d %10d %10d %10d %10d %10d\n", z_array[0], z_array[1], z_array[2], z_array[3], z_array[4], z_array[5], z_array[6], z_array[7], z_array[8], z_array[9]);

            total += end - start;
        }

        if (!best || total < best) {
            best = total;
        }
    }
    //printf("\e[0m  Quad Sort            : sorted %d elements in %f seconds. (%s)\n", max, best / 1000000.0, desc);

    for (cnt = 1; cnt < max; cnt++)
        if (z_array[cnt - 1] > z_array[cnt]) printf("        Quad Sort: not properly sorted at index %d. (%d vs %d\n", cnt, z_array[cnt - 1], z_array[cnt]);
	return best / 1000000.0;
}

void test_quick(int * z_array, int * r_array, int max, int rep, char * desc) {
    long long start, end, total, best;
    int cnt, sam, stp;

    best = 0;

    for (sam = 0; sam < 1; sam++) {
        total = 0;

        for (stp = 0; stp < rep; stp++) {
            memcpy(z_array, r_array, max * sizeof(int));

            if (sam == 0 && stp == 0 && max <= 10) printf("\e[1;31m%10d %10d %10d %10d %10d %10d %10d %10d %10d %10d\n", z_array[0], z_array[1], z_array[2], z_array[3], z_array[4], z_array[5], z_array[6], z_array[7], z_array[8], z_array[9]);

            start = utime();

            qsort(z_array, max, sizeof(int), cmp_int);

            end = utime();

            if (sam == 0 && stp == 0 && max <= 10) printf("\e[1;32m%10d %10d %10d %10d %10d %10d %10d %10d %10d %10d\n", z_array[0], z_array[1], z_array[2], z_array[3], z_array[4], z_array[5], z_array[6], z_array[7], z_array[8], z_array[9]);

            total += end - start;
        }

        if (!best || total < best) {
            best = total;
        }
    }
    printf("\e[0m  Quick Sort           : sorted %d elements in %f seconds. (%s)\n", max, best / 1000000.0, desc);

    for (cnt = 1; cnt < max; cnt++)
        if (z_array[cnt - 1] > z_array[cnt]) printf("       Quick Sort: not properly sorted at index %d. (%d vs %d\n", cnt, z_array[cnt - 1], z_array[cnt]);
}

void generate(int *arr, int datanumber, char unit, int *sequence, int *sizes) {
	//printf("Sequence output: ");
	srand(time(0));
	int max = 1;
	int random, num = rand() % 100;
	int n = 0;
	
	int seq = 0;
	int choice = sequence[seq++];
	int size = sizes[choice];
	//printf("Choice: %d Size: %d Sequence: ", choice, size);
	while (choice != 0) {
		if (choice != 0) {
			int datasize = 0;
			if (unit == 'k' || unit == 'K') {
				datasize = datanumber * 1024 / 4 * size;
			}
			if (unit == 'm' || unit == 'M') {
				datasize = datanumber * 1024 * 1024 / 4 * size;
			}
			if (datasize != 0) {
				max = datasize;
			} else {
				max = datanumber / 4 * size;
			}
		}
		switch (choice) {
		    case 1:
		        //----------------------ascending
		        //num = 0;
		        num = rand() % 100;
		        for (int i = 0; i < max; i++, n++) {
		            random = (rand() % (2 - 1 + 1)) + 1;
		            num += random;
		            //fprintf(fptr, "%d,", num);
		            arr[n] = num;
		        }
		        //printf("1");
		        break;
		    
		    case 2:
		        //--------------------------------descending
		        //num = max;
		        num = rand() % max;
		        for (int i = 0; i < max; i++, n++) {
		            random = (rand() % (2 - 1 + 1)) + 1;
		            num -= random;
		            //fprintf(fptr, "%d,", num);
		            arr[n] = num;
		        }
		        //printf("2");
		        break;
		    
		    case 3:
		        //--------------------------------constant
		        //num = 6;
		        num = rand() % 100;
		        for (int i = 0; i < max - 1; i++, n++) {
		            //fprintf(fptr, "%d,", num);
		            arr[n] = num;
		        }
		        //printf("3");
		        break;
			
			case 4:
		        //--------------------------------random
		        //num = 0;
		        num = rand() % 100;
		        for (int i = 0; i < max; i++, n++) {
		            random = (rand() % (2 - 1 + 1)) + 1;
		            if (i % 2) {
		                num += random;
		            } else {
		                num -= random;
		            }
		            //fprintf(fptr, "%d,", num);
		            arr[n] = num;
		        }
		        //printf("4");
		        break;

		    case 0:
		    	//printf(": ");
		    	return;
		        break;
		        
		    default:
		    	//printf("Number not found\n");
		    	return;
		}
        choice = sequence[seq++];
        size = sizes[choice];
    }
    //printf("\n");
}

int main(int argc, char ** argv) {
/*--------- Data User Changes ---------*/
	int datanumber = 8, repeat_times = 100;
	char unit = 'k';
/*--------- Data User Changes ---------*/
	printf("Please enter the SIZE of data     -->  ");
    scanf("%d", & datanumber);
    printf("Enter the Units of data[K or M or N(no unit)]   -->  ");
    scanf(" %c", & unit);
	printf("Please enter the test repeat times     -->  ");
	scanf("%d", & repeat_times);
	
	
	double start = utime();
	FILE *sheet = fopen("Sorting_Method_Times_by_Sequence-Template.csv", "r");
	if (sheet == NULL) {
		printf("There was an error opening the csv.");
		exit(1);
	}
	
	FILE *copy = fopen("Sorting_Method_Times_by_Sequence-Kiehl.csv", "w+");
	if (sheet == NULL) {
		printf("There was an error creating a new csv.");
		exit(2);
	}
	
	int len = 255;
	char buffer[len+1];
	buffer[len] = '\0';
	char cell[16];
	cell[15] = '\0';
	fgets(buffer, len, sheet);
	fputs(buffer, copy);
	

	
	int datasize = 0;
	if (unit == 'k' || unit == 'K') {
        datasize = datanumber * 1024;
    }
    if (unit == 'm' || unit == 'M') {
        datasize = datanumber * 1024 * 1024;
    }
	static int max;
	if (datasize != 0) {
	    max = datasize;
	} else {
	    max = datanumber;
	}

	int cnt, rnd;
	int * z_array, * r_array;

	rnd = 1;
	srand(rnd);

	z_array = malloc(max * sizeof(int));
	r_array = malloc(max * sizeof(int));
		
	while (fgets(buffer, len, sheet) != NULL) {
		if (buffer[0] == ',') {
			fputs(buffer, copy);
			continue;
		}
		
		int z;
		char sort[16];
		int sizes[5];
		int sequence[5];
		
		for (z = 0; buffer[z] != ','; z++) {
			sort[z] = buffer[z];
		}
		sort[z++] = '\0';
		int y = 0;
		//fputs(sort, stdout);
		
		sizes[0] = 0;
		for (int i = 1; i < 5; i++) {
			sizes[i] = buffer[z] - '0';
			z+=2;
		}
		
		int s;
		for (s = 0; buffer[z] != ','; s++) {
			sequence[s] = buffer[z++] - '0';
		}
		sequence[s] = 0;
		
		/*printf(" Sizes: ");
		for (int i = 0; i < 5; i++) printf("%d,", sizes[i]);
		printf("\nSequence: ");
		for (int i = 0; i < 5; i++) printf("%d,", sequence[i]);
		printf("\n");*/
		
		generate(r_array, datanumber, unit, sequence, sizes);
		/*if (buffer[14] == '4') {
			for (int i = 0; i < 8192; i++) {
				printf("%d,", z_array[i]); 
			}
		}*/
		// asc=5; des=7; con=9; ran=11
		/*if (buffer[7] == '3') {
			for (int i = 0; i < 8192; i++) {
				printf("%d,", r_array[i]); 
			}
		}*/
		//getchar();
		
		float time = 0.0;
	    int rep = 1;
		if (strcmp(sort, "Tim") == 0) 
			for (int i = 0; i < repeat_times; i++)
		    	time  += test_tim(z_array, r_array, max, rep, "sheet order");

		else if (strcmp(sort, "Quad") == 0)
			for (int i = 0; i < repeat_times; i++)
		    	time  += test_quad(z_array, r_array, max, rep, "sheet order");
		    	
		float avg = time/((float) repeat_times);
		char average[10];
		snprintf(average, sizeof average, "%f", avg);
		
		
		for (int a = 0; average[a] != '\0' && a < sizeof average; a++) {
			buffer[++z] = average[a];
			//printf("%c", average[a]);
		}
		buffer[++z] = '\n';
		buffer[++z] = '\0';
		fputs(buffer, copy);
		//printf("\n\n");
	}
    free(z_array);
    free(r_array);
    
	double end = utime();
	double total = (end - start) / 1000000.0;
	
	printf("Task completion time: %lf\n", total);

    return 0;
}
