#define _XOPEN_SOURCE
#include <sys/time.h>
#include <time.h>

#define SORT_NAME sorter
#define SORT_TYPE int
/* You can redefine the comparison operator.
   The default is
#define SORT_CMP(x, y)  ((x) < (y) ? -1 : ((x) == (y) ? 0 : 1))
   but the one below is often faster for integer types.
*/
#define SORT_CMP(x, y)(x - y)
#define MAX(x, y)(((x) > (y) ? (x) : (y)))
#define MIN(x, y)(((x) < (y) ? (x) : (y)))
#define SORT_CSWAP(x, y) { SORT_TYPE _sort_swap_temp = MAX((x), (y)); (x) = MIN((x), (y)); (y) = _sort_swap_temp; }
#include "sort.h"

/*
------------------------------------------------
*/
/*
	Copyright (C) 2014-2020 Igor van den Hoven ivdhoven@gmail.com
*/

/*
	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/*
	quadsort 1.1
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <math.h>


typedef int CMPFUNC(const void * a,
    const void * b);
/*
------------------------------------------------
*/
void verify(int * dst, const int size) {
    int i;

    for (i = 1; i < size; i++) {
        if (dst[i - 1] > dst[i]) {
            printf("Verify failed! at %d\n", i);
            /*
                  for (i = i - 2; i < SIZE; i++) {
                    printf(" %lld", (long long) dst[i]);
                  }
            */
            printf("\n");
            break;
        }
    }
}

void swap(int * a, int * b) {
    int temp;
    temp = * a;
    * a = * b;
    * b = temp;
}
/*
------------------------------------------------
*/
// benchmarking utilities

long long utime() {
    struct timeval now_time;

    gettimeofday( & now_time, NULL);

    return now_time.tv_sec * 1000000LL + now_time.tv_usec;
}
/*
------------------------------------------------
*/
//tim sort
float test_tim(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        sorter_tim_sort(z_array, max);
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    //printf("\e[0m  Tim Sort             : sorted %d elements in %f seconds. (%s)\n", max, total / 1000000.0, desc);
    return total / 1000000.0;
}
//selection sort
float test_selection(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        sorter_selection_sort(z_array, max);
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    //printf("\e[0m  Selection Sort       : sorted %d elements in %f seconds. (%s)\n", max, total / 1000000.0, desc);
    return total / 1000000.0;
}
//bubble sort
float test_bubble(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        sorter_bubble_sort(z_array, max);
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    //printf("\e[0m  Bubble Sort          : sorted %d elements in %f seconds. (%s)\n", max, total / 1000000.0, desc);
    return total / 1000000.0;
}
//bitonic sort
float test_bitonic(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        sorter_bitonic_sort(z_array, max);
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    //printf("\e[0m  Bitonic Sort         : sorted %d elements in %f seconds. (%s)\n", max, total / 1000000.0, desc);
    return total / 1000000.0;
}
//merge sort
float test_merge(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        sorter_merge_sort(z_array, max);
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    //printf("\e[0m  Merge Sort           : sorted %d elements in %f seconds. (%s)\n", max, total / 1000000.0, desc);
    return total / 1000000.0;
}
//binary insertion
float test_binary_insertion(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        sorter_binary_insertion_sort(z_array, max);
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    //printf("\e[0m  Binary Insertion Sort: sorted %d elements in %f seconds. (%s)\n", max, total / 1000000.0, desc);
    return total / 1000000.0;
}
//heap sort
float test_heap(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        sorter_heap_sort(z_array, max);
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    //printf("\e[0m  Heap Sort            : sorted %d elements in %f seconds. (%s)\n", max, total / 1000000.0, desc);
    return total / 1000000.0;
}
//shell sort
float test_shell(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        sorter_shell_sort(z_array, max);
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    //printf("\e[0m  Shell Sort           : sorted %d elements in %f seconds. (%s)\n", max, total / 1000000.0, desc);
    return total / 1000000.0;
}
//in-place merge sort
float test_in_place_merge(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        sorter_merge_sort_in_place(z_array, max);
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    //printf("\e[0m  In-place Merge Sort  : sorted %d elements in %f seconds. (%s)\n", max, total / 1000000.0, desc);
    return total / 1000000.0;
}
//grail sort
float test_grail(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        sorter_grail_sort(z_array, max);
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    //printf("\e[0m  Grail Sort           : sorted %d elements in %f seconds. (%s)\n", max, total / 1000000.0, desc);
    return total / 1000000.0;
}
//sqrt sort
float test_sqrt(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        sorter_sqrt_sort(z_array, max);
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    //printf("\e[0m  Sqrt Sort            : sorted %d elements in %f seconds. (%s)\n", max, total / 1000000.0, desc);
    return total / 1000000.0;
}
//rec stable sort
float test_rec_stable(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        sorter_rec_stable_sort(z_array, max);
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    //printf("\e[0m  Rec Stable Sort      : sorted %d elements in %f seconds. (%s)\n", max, total / 1000000.0, desc);
    return total / 1000000.0;
}
//grail sort dyn buffer
float test_grail_dyn_buffer(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        sorter_grail_sort_dyn_buffer(z_array, max);
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    //printf("\e[0m  Grail Dyn Buffer Sort: sorted %d elements in %f seconds. (%s)\n", max, total / 1000000.0, desc);
    return total / 1000000.0;
}
//Shaker
//grail sort dyn buffer
float test_Shaker(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        //---------sharker sort-------------
        int i, j, k, m = max;
        for (i = 0; i < m;) {
            for (j = i + 1; j < m; j++) {
                if (z_array[j] < z_array[j - 1])
                    swap( & z_array[j], & z_array[j - 1]);
            }
            m--;
            for (k = m - 1; k > i; k--) {
                if (z_array[k] < z_array[k - 1])
                    swap( & z_array[k], & z_array[k - 1]);
            }
            i++;
        }
        //----------------------------------
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    //printf("\e[0m  Shaker Sort          : sorted %d elements in %f seconds. (%s)\n", max, total / 1000000.0, desc);
    return total / 1000000.0;
}
/*
------------------------------------------------
*/
void quarter_sort32(void * array, int key, size_t nmemb, CMPFUNC * cmp) {
    int * pta = array;

    switch (nmemb) {
    case 1:
        pta[1] = pta[0];
        pta[0] = key;
        return;
    case 2:
        pta[2] = pta[1];

        if (cmp( & key, & pta[0]) < 0) {
            pta[1] = pta[0];
            pta[0] = key;
        } else {
            pta[1] = key;
        }
        return;
    default:
        pta[3] = pta[2];

        if (cmp( & key, & pta[1]) < 0) {
            pta[2] = pta[1];

            if (cmp( & key, & pta[0]) < 0) {
                pta[1] = pta[0];
                pta[0] = key;
            } else {
                pta[1] = key;
            }
        } else {
            pta[2] = key;
        }
        return;
    }
}

void quarter_sort64(void * array, long long key, size_t nmemb, CMPFUNC * cmp) {
    long long * pta = array;

    switch (nmemb) {
    case 1:
        pta[1] = pta[0];
        pta[0] = key;
        return;
    case 2:
        pta[2] = pta[1];

        if (cmp( & key, & pta[0]) < 0) {
            pta[1] = pta[0];
            pta[0] = key;
        } else {
            pta[1] = key;
        }
        return;
    default:
        pta[3] = pta[2];

        if (cmp( & key, & pta[1]) < 0) {
            pta[2] = pta[1];

            if (cmp( & key, & pta[0]) < 0) {
                pta[1] = pta[0];
                pta[0] = key;
            } else {
                pta[1] = key;
            }
        } else {
            pta[2] = key;
        }
        return;
    }
}

void swap_sort32(void * array, size_t nmemb, CMPFUNC * cmp) {
    size_t offset;
    register int swap, * pta;

    pta = array;

    for (offset = 0; offset + 4 <= nmemb; offset += 4) {
        if (cmp( & pta[0], & pta[1]) > 0) {
            swap = pta[0];
            pta[0] = pta[1];
            pta[1] = swap;
        }

        if (cmp( & pta[1], & pta[2]) > 0) {
            if (cmp( & pta[0], & pta[2]) > 0) {
                swap = pta[2];
                pta[2] = pta[1];
                pta[1] = pta[0];
                pta[0] = swap;
            } else {
                swap = pta[2];
                pta[2] = pta[1];
                pta[1] = swap;
            }
        }

        if (cmp( & pta[2], & pta[3]) > 0) {
            if (cmp( & pta[0], & pta[3]) > 0) {
                swap = pta[3];
                pta[3] = pta[2];
                pta[2] = pta[1];
                pta[1] = pta[0];
                pta[0] = swap;
            } else if (cmp( & pta[1], & pta[3]) > 0) {
                swap = pta[3];
                pta[3] = pta[2];
                pta[2] = pta[1];
                pta[1] = swap;
            } else {
                swap = pta[3];
                pta[3] = pta[2];
                pta[2] = swap;
            }
        }

        pta += 4;
    }

    for (swap = 1; offset + swap < nmemb; swap++) {
        if (cmp( & pta[swap], & pta[swap - 1]) < 0) {
            quarter_sort32(pta, pta[swap], swap, cmp);
        }
    }
}

void swap_sort64(void * array, size_t nmemb, CMPFUNC * cmp) {
    size_t offset;
    register long long swap, * pta;

    pta = array;

    for (offset = 0; offset + 4 <= nmemb; offset += 4) {
        if (cmp( & pta[0], & pta[1]) > 0) {
            swap = pta[0];
            pta[0] = pta[1];
            pta[1] = swap;
        }

        if (cmp( & pta[1], & pta[2]) > 0) {
            if (cmp( & pta[0], & pta[2]) > 0) {
                swap = pta[2];
                pta[2] = pta[1];
                pta[1] = pta[0];
                pta[0] = swap;
            } else {
                swap = pta[2];
                pta[2] = pta[1];
                pta[1] = swap;
            }
        }

        if (cmp( & pta[2], & pta[3]) > 0) {
            if (cmp( & pta[0], & pta[3]) > 0) {
                swap = pta[3];
                pta[3] = pta[2];
                pta[2] = pta[1];
                pta[1] = pta[0];
                pta[0] = swap;
            } else if (cmp( & pta[1], & pta[3]) > 0) {
                swap = pta[3];
                pta[3] = pta[2];
                pta[2] = pta[1];
                pta[1] = swap;
            } else {
                swap = pta[3];
                pta[3] = pta[2];
                pta[2] = swap;
            }
        }

        pta += 4;
    }

    for (swap = 1; offset + swap < nmemb; swap++) {
        if (cmp( & pta[swap], & pta[swap - 1]) < 0) {
            quarter_sort64(pta, pta[swap], swap, cmp);
        }
    }
}

void quad_sort32(void * array, void * swap, size_t block, size_t nmemb, CMPFUNC * cmp) {
    size_t offset;
    register int * pta, * pts, * c, * c_max, * d, * d_max, * end;

    end = (int * ) array + nmemb;

    while (block < nmemb) {
        offset = 0;

        while (offset + block < nmemb) {
            pta = (int * ) array + offset;

            d_max = pta + block;

            if (cmp(d_max - 1, d_max) <= 0) {
                if (offset + block * 3 < nmemb) {
                    d_max = pta + block * 2;

                    if (cmp(d_max - 1, d_max) <= 0) {
                        d_max = offset + block * 4 <= nmemb ? pta + block * 3 : end;

                        if (cmp(d_max - 1, d_max) <= 0) {
                            offset += block * 4;
                            continue;
                        }
                    }
                } else if (offset + block * 2 < nmemb) {
                    d_max = offset + block * 2 <= nmemb ? pta + block * 2 : end;

                    if (cmp(d_max - 1, d_max) <= 0) {
                        offset += block * 4;
                        continue;
                    }
                } else {
                    offset += block * 4;
                    continue;
                }
            }

            pts = (int * ) swap;

            c = pta;
            c_max = pta + block;

            d = c_max;
            d_max = offset + block * 2 <= nmemb ? d + block : end;

            if (cmp(c_max - 1, d_max - 1) <= 0) {
                while (c < c_max) {
                    while (cmp(c, d) > 0) {
                        * pts++ = * d++;
                    }
                    * pts++ = * c++;
                }
                while (d < d_max)
                    *
                    pts++ = * d++;
            } else if (cmp(c, d_max - 1) > 0) {
                while (d < d_max)
                    *
                    pts++ = * d++;

                while (c < c_max)
                    *
                    pts++ = * c++;
            } else {
                while (d < d_max) {
                    while (cmp(c, d) <= 0) {
                        * pts++ = * c++;
                    }
                    * pts++ = * d++;
                }

                while (c < c_max) {
                    * pts++ = * c++;
                }
            }

            if (offset + block * 2 < nmemb) {
                c = pta + block * 2;

                if (offset + block * 3 < nmemb) {
                    c_max = c + block;
                    d = c_max;
                    d_max = offset + block * 4 <= nmemb ? d + block : end;

                    if (cmp(c_max - 1, d_max - 1) <= 0) {
                        while (c < c_max) {
                            while (cmp(c, d) > 0) {
                                * pts++ = * d++;
                            }
                            * pts++ = * c++;
                        }
                        while (d < d_max)
                            *
                            pts++ = * d++;
                    } else if (cmp(c, d_max - 1) > 0) {
                        while (d < d_max)
                            *
                            pts++ = * d++;
                        while (c < c_max)
                            *
                            pts++ = * c++;
                    } else {
                        while (d < d_max) {
                            while (cmp(c, d) <= 0) {
                                * pts++ = * c++;
                            }
                            * pts++ = * d++;
                        }
                        while (c < c_max)
                            *
                            pts++ = * c++;
                    }
                } else {
                    while (c < end)
                        *
                        pts++ = * c++;
                }
            }

            pts = (int * ) swap;

            c = pts;

            if (offset + block * 2 < nmemb) {
                c_max = c + block * 2;

                d = c_max;
                d_max = offset + block * 4 <= nmemb ? d + block * 2 : pts + nmemb - offset;

                if (cmp(c_max - 1, d_max - 1) <= 0) {
                    while (c < c_max) {
                        while (cmp(c, d) > 0) {
                            * pta++ = * d++;
                        }
                        * pta++ = * c++;
                    }
                    while (d < d_max)
                        *
                        pta++ = * d++;
                } else if (cmp(c, d_max - 1) > 0) {
                    while (d < d_max)
                        *
                        pta++ = * d++;
                    while (c < c_max)
                        *
                        pta++ = * c++;
                } else {
                    while (d < d_max) {
                        while (cmp(d, c) > 0) {
                            * pta++ = * c++;
                        }
                        * pta++ = * d++;
                    }
                    while (c < c_max)
                        *
                        pta++ = * c++;
                }
            } else {
                d_max = pts + nmemb - offset;

                while (c < d_max)
                    *
                    pta++ = * c++;
            }
            offset += block * 4;
        }
        block *= 4;
    }
}

void quad_sort64(void * array, void * swap, size_t block, size_t nmemb, CMPFUNC * cmp) {
    size_t offset;
    register long long * pta, * pts, * c, * c_max, * d, * d_max, * end;

    end = (long long * ) array + nmemb;

    while (block < nmemb) {
        offset = 0;

        while (offset + block < nmemb) {
            pta = (long long * ) array + offset;

            d_max = pta + block;

            if (cmp(d_max - 1, d_max) <= 0) {
                if (offset + block * 3 < nmemb) {
                    d_max = pta + block * 2;

                    if (cmp(d_max - 1, d_max) <= 0) {
                        d_max = offset + block * 4 <= nmemb ? pta + block * 3 : end;

                        if (cmp(d_max - 1, d_max) <= 0) {
                            offset += block * 4;
                            continue;
                        }
                    }
                } else if (offset + block * 2 < nmemb) {
                    d_max = offset + block * 2 <= nmemb ? pta + block * 2 : end;

                    if (cmp(d_max - 1, d_max) <= 0) {
                        offset += block * 4;
                        continue;
                    }
                } else {
                    offset += block * 4;
                    continue;
                }
            }

            pts = (long long * ) swap;

            c = pta;
            c_max = pta + block;

            d = c_max;
            d_max = offset + block * 2 <= nmemb ? d + block : end;

            if (cmp(c, d_max - 1) > 0) {
                while (d < d_max)
                    *
                    pts++ = * d++;

                while (c < c_max)
                    *
                    pts++ = * c++;
            } else {
                if (cmp(c_max - 1, d_max - 1) <= 0) {
                    while (c < c_max) {
                        while (cmp(c, d) > 0) {
                            * pts++ = * d++;
                        }
                        * pts++ = * c++;
                    }
                    while (d < d_max)
                        *
                        pts++ = * d++;
                } else {
                    while (d < d_max) {
                        while (cmp(c, d) <= 0) {
                            * pts++ = * c++;
                        }
                        * pts++ = * d++;
                    }

                    while (c < c_max) {
                        * pts++ = * c++;
                    }
                }
            }

            if (offset + block * 2 < nmemb) {
                c = pta + block * 2;

                if (offset + block * 3 < nmemb) {
                    c_max = c + block;
                    d = c_max;
                    d_max = offset + block * 4 <= nmemb ? d + block : end;

                    if (cmp(c, d_max - 1) > 0) {
                        while (d < d_max)
                            *
                            pts++ = * d++;
                        while (c < c_max)
                            *
                            pts++ = * c++;
                    } else {
                        if (cmp(c_max - 1, d_max - 1) <= 0) {
                            while (c < c_max) {
                                while (cmp(c, d) > 0) {
                                    * pts++ = * d++;
                                }
                                * pts++ = * c++;
                            }
                            while (d < d_max)
                                *
                                pts++ = * d++;
                        } else {
                            while (d < d_max) {
                                while (cmp(c, d) <= 0) {
                                    * pts++ = * c++;
                                }
                                * pts++ = * d++;
                            }
                            while (c < c_max)
                                *
                                pts++ = * c++;
                        }
                    }
                } else {
                    while (c < end)
                        *
                        pts++ = * c++;
                }
            }

            pts = (long long * ) swap;

            c = pts;

            if (offset + block * 2 < nmemb) {
                c_max = c + block * 2;

                d = c_max;
                d_max = offset + block * 4 <= nmemb ? d + block * 2 : pts + nmemb - offset;

                if (cmp(c, d_max - 1) > 0) {
                    while (d < d_max)
                        *
                        pta++ = * d++;
                    while (c < c_max)
                        *
                        pta++ = * c++;
                } else {
                    if (cmp(c_max - 1, d_max - 1) <= 0) {
                        while (c < c_max) {
                            while (cmp(c, d) > 0) {
                                * pta++ = * d++;
                            }
                            * pta++ = * c++;
                        }
                        while (d < d_max)
                            *
                            pta++ = * d++;
                    } else {
                        while (d < d_max) {
                            while (cmp(d, c) > 0) {
                                * pta++ = * c++;
                            }
                            * pta++ = * d++;
                        }
                        while (c < c_max)
                            *
                            pta++ = * c++;
                    }
                }

            } else {
                d_max = pts + nmemb - offset;

                while (c < d_max)
                    *
                    pta++ = * c++;
            }
            offset += block * 4;
        }
        block *= 4;
    }
}

void quadsort(void * array, size_t nmemb, size_t size, CMPFUNC * cmp) {
    void * swap;

    swap = malloc(nmemb * size);

    if (size == sizeof(int)) {
        swap_sort32(array, nmemb, cmp);

        quad_sort32(array, swap, 4, nmemb, cmp);
    } else if (size == sizeof(long long)) {
        swap_sort64(array, nmemb, cmp);

        quad_sort64(array, swap, 4, nmemb, cmp);
    }

    free(swap);
}

int cmp_int(const void * a,
    const void * b) {
    return *(int * ) a - * (int * ) b;
}

int cmp_str(const void * a,
    const void * b) {
    return strcmp( * (const char ** ) a, *(const char ** ) b);
}

float test_quad(int * z_array, int * r_array, int max, int rep, char * desc) {
    long long start, end, total, best;
    int cnt, sam, stp;

    best = 0;

    for (sam = 0; sam < 1; sam++) {
        total = 0;

        for (stp = 0; stp < rep; stp++) {
            memcpy(z_array, r_array, max * sizeof(int));

            if (sam == 0 && stp == 0 && max <= 10) printf("\e[1;31m%10d %10d %10d %10d %10d %10d %10d %10d %10d %10d\n", z_array[0], z_array[1], z_array[2], z_array[3], z_array[4], z_array[5], z_array[6], z_array[7], z_array[8], z_array[9]);

            start = utime();

            quadsort(z_array, max, sizeof(int), cmp_int);

            end = utime();

            if (sam == 0 && stp == 0 && max <= 10) printf("\e[1;32m%10d %10d %10d %10d %10d %10d %10d %10d %10d %10d\n", z_array[0], z_array[1], z_array[2], z_array[3], z_array[4], z_array[5], z_array[6], z_array[7], z_array[8], z_array[9]);

            total += end - start;
        }

        if (!best || total < best) {
            best = total;
        }
    }
    //printf("\e[0m  Quad Sort            : sorted %d elements in %f seconds. (%s)\n", max, best / 1000000.0, desc);

    for (cnt = 1; cnt < max; cnt++)
        if (z_array[cnt - 1] > z_array[cnt]) printf("        Quad Sort: not properly sorted at index %d. (%d vs %d\n", cnt, z_array[cnt - 1], z_array[cnt]);
	return best / 1000000.0;
}

float test_quick(int * z_array, int * r_array, int max, int rep, char * desc) {
    long long start, end, total, best;
    int cnt, sam, stp;

    best = 0;

    for (sam = 0; sam < 1; sam++) {
        total = 0;

        for (stp = 0; stp < rep; stp++) {
            memcpy(z_array, r_array, max * sizeof(int));

            if (sam == 0 && stp == 0 && max <= 10) printf("\e[1;31m%10d %10d %10d %10d %10d %10d %10d %10d %10d %10d\n", z_array[0], z_array[1], z_array[2], z_array[3], z_array[4], z_array[5], z_array[6], z_array[7], z_array[8], z_array[9]);

            start = utime();

            qsort(z_array, max, sizeof(int), cmp_int);

            end = utime();

            if (sam == 0 && stp == 0 && max <= 10) printf("\e[1;32m%10d %10d %10d %10d %10d %10d %10d %10d %10d %10d\n", z_array[0], z_array[1], z_array[2], z_array[3], z_array[4], z_array[5], z_array[6], z_array[7], z_array[8], z_array[9]);

            total += end - start;
        }

        if (!best || total < best) {
            best = total;
        }
    }
    //printf("\e[0m  Quick Sort           : sorted %d elements in %f seconds. (%s)\n", max, best / 1000000.0, desc);

    for (cnt = 1; cnt < max; cnt++)
        if (z_array[cnt - 1] > z_array[cnt]) printf("       Quick Sort: not properly sorted at index %d. (%d vs %d\n", cnt, z_array[cnt - 1], z_array[cnt]);
    return best / 1000000.0;
}

void generate(int *arr, int datanumber, char unit, int *sequence, int *sizes) {
	srand(time(0));
	// Varaible Defaults
	int max = 1;
	int random, num = rand() % 100;
	int n = 0;
	
	// Used to help with multiple type generation
	int seq = 0;
	int choice = sequence[seq++];
	int size = sizes[choice];
	// Until all the choices in the sequence have gone
	while (choice != 0) {
		// Determining size for this part of the data
		if (choice != 0) {
			int datasize = 0;
			if (unit == 'k' || unit == 'K') {
				datasize = datanumber * 1024 / 4 * size;
			}
			if (unit == 'm' || unit == 'M') {
				datasize = datanumber * 1024 * 1024 / 4 * size;
			}
			if (datasize != 0) {
				max = datasize;
			} else {
				max = datanumber / 4 * size;
			}
		}
		// Create data based on the part of the sequence
		switch (choice) {
		    case 1:
		        //----------------------ascending
		        num = rand() % 100;
		        for (int i = 0; i < max; i++, n++) {
		            random = (rand() % (2 - 1 + 1)) + 1;
		            num += random;
		            arr[n] = num;
		        }
		        break;
		    
		    case 2:
		        //--------------------------------descending
		        num = rand() % max;
		        for (int i = 0; i < max; i++, n++) {
		            random = (rand() % (2 - 1 + 1)) + 1;
		            num -= random;
		            arr[n] = num;
		        }
		        break;
		    
		    case 3:
		        //--------------------------------constant
		        num = rand() % 100;
		        for (int i = 0; i < max; i++, n++) {
		            arr[n] = num;
		        }
		        break;
			
			case 4:
		        //--------------------------------random
		        num = rand() % 100;
		        for (int i = 0; i < max; i++, n++) {
		            random = (rand() % (2 - 1 + 1)) + 1;
		            if (i % 2) {
		                num += random;
		            } else {
		                num -= random;
		            }
		            arr[n] = num;
		        }
		        break;

		    case 0:
		    	return;
		        break;
		        
		    default:
		    	return;
		}
		// Increment to the next number in the sequence
        choice = sequence[seq++];
        size = sizes[choice];
    }
}

int main(int argc, char ** argv) {
	/*---------* Get Data Size *---------*/
	/*--------- Data User Changes ---------*/

	int datanumber = 8, repeat_times = 1;
	char unit = 'k';
	int genSeq[5], genSizes[5];
	int capeRep = 1;

	printf("Please enter the size of data     -->  ");
	scanf("%d", & datanumber);
	printf("Enter the units of data [K or M or N(no unit)]   -->  ");
	scanf(" %c", & unit);
	
	/* Add sequence generation here */
	for (int i = 0, total = 0; total != 4; i++) { // While there is not a whole sequence yet
		if (i > 4) { // The total amount became greater than 4
			printf("The amount requested is more than the initial data size. Please try again.");
			i=0; // Resets the sequence so the user can fix mistakes made from the beginning
			continue;
		}
		int data = 0;
		while (data < 1 || data > 4) { // While data is not 1-4, get the data-type
			printf("Please enter the type of data you want:\nAscending:  1\nDescending: 2\nConstant:   3\nRandom:     4\n");
			scanf("%d", & data);
		}
		
		int size;
		do { // Get the size of this part of the sequence
			printf("Please enter the size (assuming 4 is the total amount)   -->  "); // (hardcoded)
			scanf("%d", & size);
		} while (total + size > 4); // Re-ask if the data size entered was too large
		
		total += size;
		genSizes[data] = size;
		genSeq[i] = data;
	}
	printf("Enter the repeat times   -->  ");
	scanf("%d", & capeRep);
	
	/**--------- Data User Changes ---------**/
	
	double start = utime(); // To determine how long the program ran

	// Determining size of data and setting up arrays
	int datasize = 0;
	if (unit == 'k' || unit == 'K') {
        datasize = datanumber * 1024;
    }
    if (unit == 'm' || unit == 'M') {
        datasize = datanumber * 1024 * 1024;
    }
	static int max;
	if (datasize != 0) {
	    max = datasize;
	} else {
	    max = datanumber;
	}
	
	/**---------* Get Data Size *---------**/
	/*---------* Generate Data *---------*/
	
	// The variables holding the total time for each algorithm.
	float capeT, quadT, quickT, timT, selectionT, bubbleT, bitonicT, mergeT, binInsT, heapT, shellT, mergeInT, grailT, sqrtT, recStableT, grailDynT, shakerT;

for (int asdf = 0; asdf < capeRep; asdf++) {
	int * z_array, * r_array; // The arrays holding the data
	int rnd = 1;
	srand(rnd);

	z_array = malloc(max * sizeof(int)); // The array that will be sorted
	r_array = malloc(max * sizeof(int)); // The original data set
	
	generate(r_array, datanumber, unit, genSeq, genSizes); // Generates data based on sequence
	
	memcpy(z_array, r_array, max * sizeof(int));
	
	/**---------* Generate Data *---------**/
	/*---------* Start Cape Sort *---------*/
	double capeStart = utime();
	/*---------* Open Dictionary *---------*/
	
	// The dictionary to read
	FILE *dictionary = fopen("CapeSort_Dictionary.csv", "r");
	if (dictionary == NULL) {
		printf("There was an error opening the dictionary.");
		exit(1);
	}
	
	// Setting up buffer to read dictionary line by line
	int len = 255;
	char buffer[len+1];
	buffer[len] = '\0';
	
	// Skipping the first line (headers)
	fgets(buffer, len, dictionary);
	
	/**---------* Open Dictionary *---------**/
	/*---------* Sample the Data *---------*/
	
	int samples = max * 0.2; // Number of samples we need to take
	int window = 5; // The size of each window
	int groups = 4; // The number of windows we look at: samples / window (hardcoded)
	int increment = max / (groups + 1); // How far apart each window is (beginning to beginning)
	int cursor; // The int that will reference each point in a window, starts on first window
	
	int sampleSeq[groups+1]; // Asc: 1, Des: 2, Con: 3, Ran: 4
	int samCur = 0; // The cursor for moving through the sampleSeq array
	
	int test = 1;
	for (cursor = 0 - (int)(window/2) + increment; cursor + 5 < max; cursor += increment - window) {
		int comp[window-1]; // The amount of comparisons is 1 less than the amount in a window
		int asc = 0, des = 0, con = 0; // The amount of each comparison
		
		for (int i = 0; i < window - 1; i++) { // Compare items in the window
			if (z_array[cursor] < z_array[cursor+1]) { // Asc: 1
				asc++;
			}
			else if (z_array[cursor] > z_array[cursor+1]) { // Des: 2
				des++;
			}
			else if (z_array[cursor] == z_array[cursor+1]) { // Con: 3
				con++;
			}
			cursor++;
		}
		cursor++;
		
		if (asc == window-1) {
			sampleSeq[samCur++] = 1;
		}
		else if (des == window-1) {
			sampleSeq[samCur++] = 2;
		}
		else if (con == window-1) {
			sampleSeq[samCur++] = 3;
		}
		else {
			sampleSeq[samCur++] = 4;
		}
	}
	sampleSeq[samCur] = 0;
	
	/**---------* Sample the Data *---------**/
	/*---------* Get Data Type Ratios *---------*/
	int sampleSizes[5] = {0,0,0,0,0}; // The sizes of the data types: groups+1 (hardcoded)
	for (int size = samCur, samCur = 0; samCur < size; samCur++) { // For the amount of items in sampleSizes
		if (sampleSeq[samCur] == 1) { // Ascending
			sampleSizes[1]++;
		}
		else if (sampleSeq[samCur] == 2) { // Descending
			sampleSizes[2]++;
		}
		else if (sampleSeq[samCur] == 3) { // Constant
			sampleSizes[3]++;
		}
		else if (sampleSeq[samCur] == 4) { // Random
			sampleSizes[4]++;
		}
	}
	
	/**---------* Get Data Type Ratios *---------**/
	/*---------* Search Dictionary  *---------*/
	
	char sort[16]; // Name of sort
	while (fgets(buffer, len, dictionary) != NULL) {
		int z; // Cursor on line
		int dictSizes[5]; // List of sizes for data types
		int tempSeq[5] = {0,0,0,0,0}; // Temporary sequence to change for better reading
		int dictSeq[5] = {0,0,0,0,0}; // Sequence of data types
		
		// Get the name of the sort
		for (z = 0; buffer[z] != ','; z++) {
			sort[z] = buffer[z];
		}
		sort[z++] = '\0';
		int y = 0;
		
		// Get the sizes and put them in order (sizes[0] = 0 so when referencing, 1=1, 2=2, etc.
		dictSizes[0] = 0;
		for (int i = 1; i < 5; i++) {
			dictSizes[i] = buffer[z] - '0';
			z+=2;
		}
		
		// Get the sequence
		int t;
		for (t = 0; buffer[z] != ','; t++) {
			tempSeq[t] = buffer[z++] - '0';
		}
		tempSeq[t] = 0;
		
		// Convert the sequence
		int s = 0;
		for (t = 0; tempSeq[t] != 0; t++) {
			for (int i = 0; i < dictSizes[tempSeq[t]]; i++) {
				dictSeq[s++] = tempSeq[t];
			}
		}
		
		// Check sizes
		for (int i = 1; i < 5; i++) {
			if (dictSizes[i] != sampleSizes[i]) { // Not a match
				goto noMatch; // Next reference
			}
		}
		
		// Check sequence
		for (int i = 0; i < 5; i++) {
			if (dictSeq[i] != sampleSeq[i]) { // Not a match
				goto noMatch; // Next reference
			}
		}
		
		
		break; // Match found, moving on
		
		noMatch: // Not a match
		continue;
	}
	
	/**---------* Search Dictionary *---------**/
	/*---------* Run Recommended Sort *---------*/
	
	if (strcmp(sort, "Quad") == 0) {
		quadsort(z_array, max, sizeof(int), cmp_int);
	}
		
	else if (strcmp(sort, "Tim") == 0) {
		sorter_tim_sort(z_array, max);
	}

	else if (strcmp(sort, "Quick") == 0) {
		qsort(z_array, max, sizeof(int), cmp_int);
	}
		
	else if (strcmp(sort, "Selection") == 0) {
		sorter_selection_sort(z_array, max);
	}
		
	else if (strcmp(sort, "Bubble") == 0) {
		sorter_bubble_sort(z_array, max);
	}
		
	else if (strcmp(sort, "Bitonic") == 0) {
		sorter_bitonic_sort(z_array, max);
	}
		
	else if (strcmp(sort, "Merge") == 0) {
		sorter_merge_sort(z_array, max);
	}
		
	else if (strcmp(sort, "BinaryInsertion") == 0) {
		sorter_binary_insertion_sort(z_array, max);
	}
		
	else if (strcmp(sort, "Heap") == 0) {
		sorter_heap_sort(z_array, max);
	}
		
	else if (strcmp(sort, "Shell") == 0) {
		sorter_shell_sort(z_array, max);
	}
		
	else if (strcmp(sort, "MergeInPlace") == 0) {
		sorter_merge_sort_in_place(z_array, max);
	}
		
	else if (strcmp(sort, "Grail") == 0) {
		sorter_grail_sort(z_array, max);
	}
		
	else if (strcmp(sort, "Sqrt") == 0) {
		sorter_sqrt_sort(z_array, max);
	}
		
	else if (strcmp(sort, "RecStable") == 0) {
		sorter_rec_stable_sort(z_array, max);
	}
		
	else if (strcmp(sort, "GrailDyn") == 0) {
		sorter_grail_sort_dyn_buffer(z_array, max);
	}
		
	else if (strcmp(sort, "Shaker") == 0) {
    	int i, j, k, m = max;
	    for (i = 0; i < m;) {
	        for (j = i + 1; j < m; j++) {
	            if (z_array[j] < z_array[j - 1])
	                swap( & z_array[j], & z_array[j - 1]);
	        }
	        m--;
	        for (k = m - 1; k > i; k--) {
	            if (z_array[k] < z_array[k - 1])
	                swap( & z_array[k], & z_array[k - 1]);
	        }
	        i++;
	    }
	}
	
	/**---------* Run Recommended Sort *---------**/
	fclose(dictionary);
	double capeEnd = utime();
	float cape = (capeEnd - capeStart) / 1000000.0;
	/**---------* Stop Cape Sort *---------**/
	/*---------* Run Other Sorts *---------*/
	
	// Accumulate the total time it takes to run this sorting method repeat_times times
	float quad, quick, tim, selection, bubble, bitonic, merge, binIns, heap, shell, mergeIn,
			grail, sqrt, recStable, grailDyn, shaker;
	int rep = 1;
	
	// Check and run the sort while accumulating run times.
	quad		= test_quad(z_array, r_array, max, rep, "sheet order");
	tim			= test_tim(z_array, r_array, max, rep, "sheet order");
	/*quick		= test_quick(z_array, r_array, max, rep, "sheet order");
	selection	= test_selection(z_array, r_array, max, rep, "sheet order");
	bubble		= test_bubble(z_array, r_array, max, rep, "sheet order");
	bitonic		= test_bitonic(z_array, r_array, max, rep, "sheet order");
	merge		= test_merge(z_array, r_array, max, rep, "sheet order");
	binIns		= test_binary_insertion(z_array, r_array, max, rep, "sheet order");
	heap		= test_heap(z_array, r_array, max, rep, "sheet order");
	shell		= test_shell(z_array, r_array, max, rep, "sheet order");
	mergeIn		= test_in_place_merge(z_array, r_array, max, rep, "sheet order");
	grail		= test_grail(z_array, r_array, max, rep, "sheet order");
	sqrt		= test_sqrt(z_array, r_array, max, rep, "sheet order");
	recStable	= test_rec_stable(z_array, r_array, max, rep, "sheet order");
	grailDyn	= test_grail_dyn_buffer(z_array, r_array, max, rep, "sheet order");
	shaker		= test_Shaker(z_array, r_array, max, rep, "sheet order");*/
	
	/**---------* Run Other Sorts *---------**/
	/*---------* Compare Times *---------*/
	
	capeT += cape;
	quadT += quad;
	timT += tim;
	/*quickT += quick;
	selectionT += selection;
	bubbleT += bubble;
	bitonicT+= bitonic;
	mergeT += merge;
	binInsT += binIns;
	heapT += heap;
	shellT += shell;
	mergeInT += mergeIn;
	grailT += grail;
	sqrtT += sqrt;
	recStableT += recStable;
	grailDynT += grailDyn;
	shakerT; += shaker;*/
	
	if (capeRep <= 15) {
		printf("\n");
		printf("\e[0m  Cape Sort            : sorted %d elements in %f seconds.\n", max, cape);
		printf("\e[0m  Quad Sort            : sorted %d elements in %f seconds.\n", max, quad);
		printf("\e[0m  Tim Sort             : sorted %d elements in %f seconds.\n", max, tim);
		/*printf("\e[0m  Quick Sort           : sorted %d elements in %f seconds.\n", max, quick);
		printf("\e[0m  Selection Sort       : sorted %d elements in %f seconds.\n", max, selection);
		printf("\e[0m  Bubble Sort          : sorted %d elements in %f seconds.\n", max, bubble);
		printf("\e[0m  Bitonic Sort         : sorted %d elements in %f seconds.\n", max, bitonic);
		printf("\e[0m  Merge Sort           : sorted %d elements in %f seconds.\n", max, merge);
		printf("\e[0m  Binary Insertion Sort: sorted %d elements in %f seconds.\n", max, binIns);
		printf("\e[0m  Heap Sort            : sorted %d elements in %f seconds.\n", max, heap);
		printf("\e[0m  Shell Sort           : sorted %d elements in %f seconds.\n", max, shell);
		printf("\e[0m  In-place Merge Sort  : sorted %d elements in %f seconds.\n", max, mergeIn);
		printf("\e[0m  Grail Sort           : sorted %d elements in %f seconds.\n", max, grail);
		printf("\e[0m  Sqrt Sort            : sorted %d elements in %f seconds.\n", max, sqrt);
		printf("\e[0m  Rec Stable Sort      : sorted %d elements in %f seconds.\n", max, recStable);
		printf("\e[0m  Grail Dyn Buffer Sort: sorted %d elements in %f seconds.\n", max, grailDyn);
		printf("\e[0m  Shaker Sort          : sorted %d elements in %f seconds.\n", max, shaker);*/
	}
	
	// Free the arrays used from memory
	free(z_array);
	free(r_array);
}
	
	/**---------* Compare Times *---------**/
	/*---------* Export Averages *---------*/
	
	FILE *averages = fopen("Sorting_Times_Averaged.csv", "w");
	if (averages == NULL) {
		printf("There was an error opening the averages file.\n");
		exit(2);
	}
	
	char avg[16];
	fputs("Sort,Average\n", averages);
	
	fputs("Cape,", averages);
	snprintf(avg, sizeof avg, "%f", capeT/((float)(capeRep)));
	fputs(avg, averages);
	fputs("\n", averages);
	for (int i = 0; i < 16; i++) avg[i] = '\0';
	
	fputs("Quad,", averages);
	snprintf(avg, sizeof avg, "%f", quadT/((float)(capeRep)));
	fputs(avg, averages);
	fputs("\n", averages);
	for (int i = 0; i < 16; i++) avg[i] = '\0';
	
	fputs("Tim,", averages);
	snprintf(avg, sizeof avg, "%f", timT/((float)(capeRep)));
	fputs(avg, averages);
	fputs("\n", averages);
	for (int i = 0; i < 16; i++) avg[i] = '\0';
	
	
	/*fputs("Quick,", averages);
	snprintf(avg, sizeof avg, "%f", quickT/((float)(capeRep)));
	fputs(avg, averages);
	fputs("\n", averages);
	for (int i = 0; i < 16; i++) avg[i] = '\0';
	
	
	fputs("Selection,", averages);
	snprintf(avg, sizeof avg, "%f", selectionT/((float)(capeRep)));
	fputs(avg, averages);
	fputs("\n", averages);
	for (int i = 0; i < 16; i++) avg[i] = '\0';
	
	
	fputs("Bubble,", averages);
	snprintf(avg, sizeof avg, "%f", bubbleT/((float)(capeRep)));
	fputs(avg, averages);
	fputs("\n", averages);
	for (int i = 0; i < 16; i++) avg[i] = '\0';
	
	
	fputs("Bitonic,", averages);
	snprintf(avg, sizeof avg, "%f", bitonicT/((float)(capeRep)));
	fputs(avg, averages);
	fputs("\n", averages);
	for (int i = 0; i < 16; i++) avg[i] = '\0';
	
	
	fputs("Merge,", averages);
	snprintf(avg, sizeof avg, "%f", mergeT/((float)(capeRep)));
	fputs(avg, averages);
	fputs("\n", averages);
	for (int i = 0; i < 16; i++) avg[i] = '\0';
	
	
	fputs("BinaryInsertion,", averages);
	snprintf(avg, sizeof avg, "%f", binInsT/((float)(capeRep)));
	fputs(avg, averages);
	fputs("\n", averages);
	for (int i = 0; i < 16; i++) avg[i] = '\0';
	
	
	fputs("Heap,", averages);
	snprintf(avg, sizeof avg, "%f", heapT/((float)(capeRep)));
	fputs(avg, averages);
	fputs("\n", averages);
	for (int i = 0; i < 16; i++) avg[i] = '\0';
	
	
	fputs("Shell,", averages);
	snprintf(avg, sizeof avg, "%f", shellT/((float)(capeRep)));
	fputs(avg, averages);
	fputs("\n", averages);
	for (int i = 0; i < 16; i++) avg[i] = '\0';
	
	
	fputs("MergeInPlace,", averages);
	snprintf(avg, sizeof avg, "%f", mergeInT/((float)(capeRep)));
	fputs(avg, averages);
	fputs("\n", averages);
	for (int i = 0; i < 16; i++) avg[i] = '\0';
	
	
	fputs("Grail,", averages);
	snprintf(avg, sizeof avg, "%f", grailT/((float)(capeRep)));
	fputs(avg, averages);
	fputs("\n", averages);
	for (int i = 0; i < 16; i++) avg[i] = '\0';
	
	
	fputs("Sqrt,", averages);
	snprintf(avg, sizeof avg, "%f", sqrtT/((float)(capeRep)));
	fputs(avg, averages);
	fputs("\n", averages);
	for (int i = 0; i < 16; i++) avg[i] = '\0';
	
	
	fputs("RecStable,", averages);
	snprintf(avg, sizeof avg, "%f", recStableT/((float)(capeRep)));
	fputs(avg, averages);
	fputs("\n", averages);
	for (int i = 0; i < 16; i++) avg[i] = '\0';
	
	
	fputs("GrailDyn,", averages);
	snprintf(avg, sizeof avg, "%f", grailDynT/((float)(capeRep)));
	fputs(avg, averages);
	fputs("\n", averages);
	for (int i = 0; i < 16; i++) avg[i] = '\0';
	
	
	fputs("Shaker,", averages);
	snprintf(avg, sizeof avg, "%f", shakerT/((float)(capeRep)));
	fputs(avg, averages);
	fputs("\n", averages);
	for (int i = 0; i < 16; i++) avg[i] = '\0';*/
	
	fclose(averages);
	
	/**---------* Export Averages *---------**/
	/*---------* Close Out Program *---------*/
	
	// Stop the timer
	double end = utime();
	double total = (end - start) / 1000000.0;
	
	FILE *done = fopen("TestComplete.txt", "w+");
	
	// Print the time on timer
	printf("\nTask completion time:");
	fprintf(done, "Task completion time:");
	int hours = total/3600;
	int minutes = total/60 - hours*60;
	float seconds = total - minutes*60 - hours*3600;
	if (hours > 0) {
		if (hours > 1) {
			printf(" %d hours", hours);
			fprintf(done, " %d hours", hours);
		}
		else {
			printf(" %d hour", hours);
			fprintf(done, " %d hour", hours);
		}
	}
	if (minutes > 0) {
		if (minutes > 1) {
			printf(" %d minutes", minutes);
			fprintf(done, " %d minutes", minutes);
		}
		else {
			printf(" %d minute", minutes);
			fprintf(done, " %d minute", minutes);
		}
	}
	printf(" %f seconds\n", seconds);
	fprintf(done, " %f seconds\n", seconds);
	
	fclose(done);

    return 0;
    
	/**---------* Close Out Program *---------**/
}
