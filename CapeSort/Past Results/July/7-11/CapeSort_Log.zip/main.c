#define _XOPEN_SOURCE
#include <sys/time.h>
#include <time.h>

#define SORT_NAME sorter
#define SORT_TYPE int
/* You can redefine the comparison operator.
   The default is
#define SORT_CMP(x, y)  ((x) < (y) ? -1 : ((x) == (y) ? 0 : 1))
   but the one below is often faster for integer types.
*/
#define SORT_CMP(x, y)  (x - y)
#define MAX(x, y)(((x) > (y) ? (x) : (y)))
#define MIN(x, y)(((x) < (y) ? (x) : (y)))
#define SORT_CSWAP(x, y) { SORT_TYPE _sort_swap_temp = MAX((x), (y)); (x) = MIN((x), (y)); (y) = _sort_swap_temp; }
#include "sort.h"

/*
------------------------------------------------
*/
/*
	Copyright (C) 2014-2020 Igor van den Hoven ivdhoven@gmail.com
*/

/*
	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.
	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.
	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/*
	quadsort 1.1
*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

struct stat st = {0};


typedef int CMPFUNC(const void * a,
    const void * b);
/*
------------------------------------------------
*/
void verify(int * dst, const int size) {
    int i;

    for (i = 1; i < size; i++) {
        if (dst[i - 1] > dst[i]) {
            printf("Verify failed! at %d\n", i);
            /*
                  for (i = i - 2; i < SIZE; i++) {
                    printf(" %lld", (long long) dst[i]);
                  }
            */
            printf("\n");
            break;
        }
    }
}

void swap(int * a, int * b) {
    int temp;
    temp = * a;
    * a = * b;
    * b = temp;
}
/*
------------------------------------------------
*/
// benchmarking utilities

long long utime() {
    struct timeval now_time;

    gettimeofday( & now_time, NULL);

    return now_time.tv_sec * 1000000LL + now_time.tv_usec;
}
/*
------------------------------------------------
*/
//tim sort
float test_tim(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        sorter_tim_sort(z_array, max);
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    //printf("\e[0m  Tim Sort             : sorted %d elements in %f seconds. (%s)\n", max, total / 1000000.0, desc);
    return total / 1000000.0;
}
//selection sort
float test_selection(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        sorter_selection_sort(z_array, max);
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    //printf("\e[0m  Selection Sort       : sorted %d elements in %f seconds. (%s)\n", max, total / 1000000.0, desc);
    return total / 1000000.0;
}
//bubble sort
float test_bubble(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        sorter_bubble_sort(z_array, max);
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    //printf("\e[0m  Bubble Sort          : sorted %d elements in %f seconds. (%s)\n", max, total / 1000000.0, desc);
    return total / 1000000.0;
}
//bitonic sort
float test_bitonic(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        sorter_bitonic_sort(z_array, max);
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    //printf("\e[0m  Bitonic Sort         : sorted %d elements in %f seconds. (%s)\n", max, total / 1000000.0, desc);
    return total / 1000000.0;
}
//merge sort
float test_merge(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        sorter_merge_sort(z_array, max);
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    //printf("\e[0m  Merge Sort           : sorted %d elements in %f seconds. (%s)\n", max, total / 1000000.0, desc);
    return total / 1000000.0;
}
//binary insertion
float test_binary_insertion(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        sorter_binary_insertion_sort(z_array, max);
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    //printf("\e[0m  Binary Insertion Sort: sorted %d elements in %f seconds. (%s)\n", max, total / 1000000.0, desc);
    return total / 1000000.0;
}
//heap sort
float test_heap(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        sorter_heap_sort(z_array, max);
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    //printf("\e[0m  Heap Sort            : sorted %d elements in %f seconds. (%s)\n", max, total / 1000000.0, desc);
    return total / 1000000.0;
}
//shell sort
float test_shell(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        sorter_shell_sort(z_array, max);
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    //printf("\e[0m  Shell Sort           : sorted %d elements in %f seconds. (%s)\n", max, total / 1000000.0, desc);
    return total / 1000000.0;
}
//in-place merge sort
float test_in_place_merge(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        sorter_merge_sort_in_place(z_array, max);
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    //printf("\e[0m  In-place Merge Sort  : sorted %d elements in %f seconds. (%s)\n", max, total / 1000000.0, desc);
    return total / 1000000.0;
}
//grail sort
float test_grail(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        sorter_grail_sort(z_array, max);
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    //printf("\e[0m  Grail Sort           : sorted %d elements in %f seconds. (%s)\n", max, total / 1000000.0, desc);
    return total / 1000000.0;
}
//sqrt sort
float test_sqrt(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        sorter_sqrt_sort(z_array, max);
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    //printf("\e[0m  Sqrt Sort            : sorted %d elements in %f seconds. (%s)\n", max, total / 1000000.0, desc);
    return total / 1000000.0;
}
//rec stable sort
float test_rec_stable(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        sorter_rec_stable_sort(z_array, max);
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    //printf("\e[0m  Rec Stable Sort      : sorted %d elements in %f seconds. (%s)\n", max, total / 1000000.0, desc);
    return total / 1000000.0;
}
//grail sort dyn buffer
float test_grail_dyn_buffer(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        sorter_grail_sort_dyn_buffer(z_array, max);
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    //printf("\e[0m  Grail Dyn Buffer Sort: sorted %d elements in %f seconds. (%s)\n", max, total / 1000000.0, desc);
    return total / 1000000.0;
}
//Shaker
//grail sort dyn buffer
float test_Shaker(int * z_array, int * r_array, int max, int rep, char * desc) {
    double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        //---------sharker sort-------------
        int i, j, k, m = max;
        for (i = 0; i < m;) {
            for (j = i + 1; j < m; j++) {
                if (z_array[j] < z_array[j - 1])
                    swap( & z_array[j], & z_array[j - 1]);
            }
            m--;
            for (k = m - 1; k > i; k--) {
                if (z_array[k] < z_array[k - 1])
                    swap( & z_array[k], & z_array[k - 1]);
            }
            i++;
        }
        //----------------------------------
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    //printf("\e[0m  Shaker Sort          : sorted %d elements in %f seconds. (%s)\n", max, total / 1000000.0, desc);
    return total / 1000000.0;
}
/*
------------------------------------------------
*/
void quarter_sort32(void * array, int key, size_t nmemb, CMPFUNC * cmp) {
    int * pta = array;

    switch (nmemb) {
    case 1:
        pta[1] = pta[0];
        pta[0] = key;
        return;
    case 2:
        pta[2] = pta[1];

        if (cmp( & key, & pta[0]) < 0) {
            pta[1] = pta[0];
            pta[0] = key;
        } else {
            pta[1] = key;
        }
        return;
    default:
        pta[3] = pta[2];

        if (cmp( & key, & pta[1]) < 0) {
            pta[2] = pta[1];

            if (cmp( & key, & pta[0]) < 0) {
                pta[1] = pta[0];
                pta[0] = key;
            } else {
                pta[1] = key;
            }
        } else {
            pta[2] = key;
        }
        return;
    }
}

void quarter_sort64(void * array, long long key, size_t nmemb, CMPFUNC * cmp) {
    long long * pta = array;

    switch (nmemb) {
    case 1:
        pta[1] = pta[0];
        pta[0] = key;
        return;
    case 2:
        pta[2] = pta[1];

        if (cmp( & key, & pta[0]) < 0) {
            pta[1] = pta[0];
            pta[0] = key;
        } else {
            pta[1] = key;
        }
        return;
    default:
        pta[3] = pta[2];

        if (cmp( & key, & pta[1]) < 0) {
            pta[2] = pta[1];

            if (cmp( & key, & pta[0]) < 0) {
                pta[1] = pta[0];
                pta[0] = key;
            } else {
                pta[1] = key;
            }
        } else {
            pta[2] = key;
        }
        return;
    }
}

void swap_sort32(void * array, size_t nmemb, CMPFUNC * cmp) {
    size_t offset;
    register int swap, * pta;

    pta = array;

    for (offset = 0; offset + 4 <= nmemb; offset += 4) {
        if (cmp( & pta[0], & pta[1]) > 0) {
            swap = pta[0];
            pta[0] = pta[1];
            pta[1] = swap;
        }

        if (cmp( & pta[1], & pta[2]) > 0) {
            if (cmp( & pta[0], & pta[2]) > 0) {
                swap = pta[2];
                pta[2] = pta[1];
                pta[1] = pta[0];
                pta[0] = swap;
            } else {
                swap = pta[2];
                pta[2] = pta[1];
                pta[1] = swap;
            }
        }

        if (cmp( & pta[2], & pta[3]) > 0) {
            if (cmp( & pta[0], & pta[3]) > 0) {
                swap = pta[3];
                pta[3] = pta[2];
                pta[2] = pta[1];
                pta[1] = pta[0];
                pta[0] = swap;
            } else if (cmp( & pta[1], & pta[3]) > 0) {
                swap = pta[3];
                pta[3] = pta[2];
                pta[2] = pta[1];
                pta[1] = swap;
            } else {
                swap = pta[3];
                pta[3] = pta[2];
                pta[2] = swap;
            }
        }

        pta += 4;
    }

    for (swap = 1; offset + swap < nmemb; swap++) {
        if (cmp( & pta[swap], & pta[swap - 1]) < 0) {
            quarter_sort32(pta, pta[swap], swap, cmp);
        }
    }
}

void swap_sort64(void * array, size_t nmemb, CMPFUNC * cmp) {
    size_t offset;
    register long long swap, * pta;

    pta = array;

    for (offset = 0; offset + 4 <= nmemb; offset += 4) {
        if (cmp( & pta[0], & pta[1]) > 0) {
            swap = pta[0];
            pta[0] = pta[1];
            pta[1] = swap;
        }

        if (cmp( & pta[1], & pta[2]) > 0) {
            if (cmp( & pta[0], & pta[2]) > 0) {
                swap = pta[2];
                pta[2] = pta[1];
                pta[1] = pta[0];
                pta[0] = swap;
            } else {
                swap = pta[2];
                pta[2] = pta[1];
                pta[1] = swap;
            }
        }

        if (cmp( & pta[2], & pta[3]) > 0) {
            if (cmp( & pta[0], & pta[3]) > 0) {
                swap = pta[3];
                pta[3] = pta[2];
                pta[2] = pta[1];
                pta[1] = pta[0];
                pta[0] = swap;
            } else if (cmp( & pta[1], & pta[3]) > 0) {
                swap = pta[3];
                pta[3] = pta[2];
                pta[2] = pta[1];
                pta[1] = swap;
            } else {
                swap = pta[3];
                pta[3] = pta[2];
                pta[2] = swap;
            }
        }

        pta += 4;
    }

    for (swap = 1; offset + swap < nmemb; swap++) {
        if (cmp( & pta[swap], & pta[swap - 1]) < 0) {
            quarter_sort64(pta, pta[swap], swap, cmp);
        }
    }
}

void quad_sort32(void * array, void * swap, size_t block, size_t nmemb, CMPFUNC * cmp) {
    size_t offset;
    register int * pta, * pts, * c, * c_max, * d, * d_max, * end;

    end = (int * ) array + nmemb;

    while (block < nmemb) {
        offset = 0;

        while (offset + block < nmemb) {
            pta = (int * ) array + offset;

            d_max = pta + block;

            if (cmp(d_max - 1, d_max) <= 0) {
                if (offset + block * 3 < nmemb) {
                    d_max = pta + block * 2;

                    if (cmp(d_max - 1, d_max) <= 0) {
                        d_max = offset + block * 4 <= nmemb ? pta + block * 3 : end;

                        if (cmp(d_max - 1, d_max) <= 0) {
                            offset += block * 4;
                            continue;
                        }
                    }
                } else if (offset + block * 2 < nmemb) {
                    d_max = offset + block * 2 <= nmemb ? pta + block * 2 : end;

                    if (cmp(d_max - 1, d_max) <= 0) {
                        offset += block * 4;
                        continue;
                    }
                } else {
                    offset += block * 4;
                    continue;
                }
            }

            pts = (int * ) swap;

            c = pta;
            c_max = pta + block;

            d = c_max;
            d_max = offset + block * 2 <= nmemb ? d + block : end;

            if (cmp(c_max - 1, d_max - 1) <= 0) {
                while (c < c_max) {
                    while (cmp(c, d) > 0) {
                        * pts++ = * d++;
                    }
                    * pts++ = * c++;
                }
                while (d < d_max)
                    *
                    pts++ = * d++;
            } else if (cmp(c, d_max - 1) > 0) {
                while (d < d_max)
                    *
                    pts++ = * d++;

                while (c < c_max)
                    *
                    pts++ = * c++;
            } else {
                while (d < d_max) {
                    while (cmp(c, d) <= 0) {
                        * pts++ = * c++;
                    }
                    * pts++ = * d++;
                }

                while (c < c_max) {
                    * pts++ = * c++;
                }
            }

            if (offset + block * 2 < nmemb) {
                c = pta + block * 2;

                if (offset + block * 3 < nmemb) {
                    c_max = c + block;
                    d = c_max;
                    d_max = offset + block * 4 <= nmemb ? d + block : end;

                    if (cmp(c_max - 1, d_max - 1) <= 0) {
                        while (c < c_max) {
                            while (cmp(c, d) > 0) {
                                * pts++ = * d++;
                            }
                            * pts++ = * c++;
                        }
                        while (d < d_max)
                            *
                            pts++ = * d++;
                    } else if (cmp(c, d_max - 1) > 0) {
                        while (d < d_max)
                            *
                            pts++ = * d++;
                        while (c < c_max)
                            *
                            pts++ = * c++;
                    } else {
                        while (d < d_max) {
                            while (cmp(c, d) <= 0) {
                                * pts++ = * c++;
                            }
                            * pts++ = * d++;
                        }
                        while (c < c_max)
                            *
                            pts++ = * c++;
                    }
                } else {
                    while (c < end)
                        *
                        pts++ = * c++;
                }
            }

            pts = (int * ) swap;

            c = pts;

            if (offset + block * 2 < nmemb) {
                c_max = c + block * 2;

                d = c_max;
                d_max = offset + block * 4 <= nmemb ? d + block * 2 : pts + nmemb - offset;

                if (cmp(c_max - 1, d_max - 1) <= 0) {
                    while (c < c_max) {
                        while (cmp(c, d) > 0) {
                            * pta++ = * d++;
                        }
                        * pta++ = * c++;
                    }
                    while (d < d_max)
                        *
                        pta++ = * d++;
                } else if (cmp(c, d_max - 1) > 0) {
                    while (d < d_max)
                        *
                        pta++ = * d++;
                    while (c < c_max)
                        *
                        pta++ = * c++;
                } else {
                    while (d < d_max) {
                        while (cmp(d, c) > 0) {
                            * pta++ = * c++;
                        }
                        * pta++ = * d++;
                    }
                    while (c < c_max)
                        *
                        pta++ = * c++;
                }
            } else {
                d_max = pts + nmemb - offset;

                while (c < d_max)
                    *
                    pta++ = * c++;
            }
            offset += block * 4;
        }
        block *= 4;
    }
}

void quad_sort64(void * array, void * swap, size_t block, size_t nmemb, CMPFUNC * cmp) {
    size_t offset;
    register long long * pta, * pts, * c, * c_max, * d, * d_max, * end;

    end = (long long * ) array + nmemb;

    while (block < nmemb) {
        offset = 0;

        while (offset + block < nmemb) {
            pta = (long long * ) array + offset;

            d_max = pta + block;

            if (cmp(d_max - 1, d_max) <= 0) {
                if (offset + block * 3 < nmemb) {
                    d_max = pta + block * 2;

                    if (cmp(d_max - 1, d_max) <= 0) {
                        d_max = offset + block * 4 <= nmemb ? pta + block * 3 : end;

                        if (cmp(d_max - 1, d_max) <= 0) {
                            offset += block * 4;
                            continue;
                        }
                    }
                } else if (offset + block * 2 < nmemb) {
                    d_max = offset + block * 2 <= nmemb ? pta + block * 2 : end;

                    if (cmp(d_max - 1, d_max) <= 0) {
                        offset += block * 4;
                        continue;
                    }
                } else {
                    offset += block * 4;
                    continue;
                }
            }

            pts = (long long * ) swap;

            c = pta;
            c_max = pta + block;

            d = c_max;
            d_max = offset + block * 2 <= nmemb ? d + block : end;

            if (cmp(c, d_max - 1) > 0) {
                while (d < d_max)
                    *
                    pts++ = * d++;

                while (c < c_max)
                    *
                    pts++ = * c++;
            } else {
                if (cmp(c_max - 1, d_max - 1) <= 0) {
                    while (c < c_max) {
                        while (cmp(c, d) > 0) {
                            * pts++ = * d++;
                        }
                        * pts++ = * c++;
                    }
                    while (d < d_max)
                        *
                        pts++ = * d++;
                } else {
                    while (d < d_max) {
                        while (cmp(c, d) <= 0) {
                            * pts++ = * c++;
                        }
                        * pts++ = * d++;
                    }

                    while (c < c_max) {
                        * pts++ = * c++;
                    }
                }
            }

            if (offset + block * 2 < nmemb) {
                c = pta + block * 2;

                if (offset + block * 3 < nmemb) {
                    c_max = c + block;
                    d = c_max;
                    d_max = offset + block * 4 <= nmemb ? d + block : end;

                    if (cmp(c, d_max - 1) > 0) {
                        while (d < d_max)
                            *
                            pts++ = * d++;
                        while (c < c_max)
                            *
                            pts++ = * c++;
                    } else {
                        if (cmp(c_max - 1, d_max - 1) <= 0) {
                            while (c < c_max) {
                                while (cmp(c, d) > 0) {
                                    * pts++ = * d++;
                                }
                                * pts++ = * c++;
                            }
                            while (d < d_max)
                                *
                                pts++ = * d++;
                        } else {
                            while (d < d_max) {
                                while (cmp(c, d) <= 0) {
                                    * pts++ = * c++;
                                }
                                * pts++ = * d++;
                            }
                            while (c < c_max)
                                *
                                pts++ = * c++;
                        }
                    }
                } else {
                    while (c < end)
                        *
                        pts++ = * c++;
                }
            }

            pts = (long long * ) swap;

            c = pts;

            if (offset + block * 2 < nmemb) {
                c_max = c + block * 2;

                d = c_max;
                d_max = offset + block * 4 <= nmemb ? d + block * 2 : pts + nmemb - offset;

                if (cmp(c, d_max - 1) > 0) {
                    while (d < d_max)
                        *
                        pta++ = * d++;
                    while (c < c_max)
                        *
                        pta++ = * c++;
                } else {
                    if (cmp(c_max - 1, d_max - 1) <= 0) {
                        while (c < c_max) {
                            while (cmp(c, d) > 0) {
                                * pta++ = * d++;
                            }
                            * pta++ = * c++;
                        }
                        while (d < d_max)
                            *
                            pta++ = * d++;
                    } else {
                        while (d < d_max) {
                            while (cmp(d, c) > 0) {
                                * pta++ = * c++;
                            }
                            * pta++ = * d++;
                        }
                        while (c < c_max)
                            *
                            pta++ = * c++;
                    }
                }

            } else {
                d_max = pts + nmemb - offset;

                while (c < d_max)
                    *
                    pta++ = * c++;
            }
            offset += block * 4;
        }
        block *= 4;
    }
}

void quadsort(void * array, size_t nmemb, size_t size, CMPFUNC * cmp) {
    void * swap;

    swap = malloc(nmemb * size);

    if (size == sizeof(int)) {
        swap_sort32(array, nmemb, cmp);

        quad_sort32(array, swap, 4, nmemb, cmp);
    } else if (size == sizeof(long long)) {
        swap_sort64(array, nmemb, cmp);

        quad_sort64(array, swap, 4, nmemb, cmp);
    }

    free(swap);
}

int cmp_int(const void * a,
    const void * b) {
    return *(int * ) a - * (int * ) b;
}

int cmp_str(const void * a,
    const void * b) {
    return strcmp( * (const char ** ) a, *(const char ** ) b);
}

float test_quad(int * z_array, int * r_array, int max, int rep, char * desc) {
    long long start, end, total, best;
    int cnt, sam, stp;

    best = 0;

    for (sam = 0; sam < 1; sam++) {
        total = 0;

        for (stp = 0; stp < rep; stp++) {
            memcpy(z_array, r_array, max * sizeof(int));

            if (sam == 0 && stp == 0 && max <= 10) printf("\e[1;31m%10d %10d %10d %10d %10d %10d %10d %10d %10d %10d\n", z_array[0], z_array[1], z_array[2], z_array[3], z_array[4], z_array[5], z_array[6], z_array[7], z_array[8], z_array[9]);

            start = utime();

            quadsort(z_array, max, sizeof(int), cmp_int);

            end = utime();

            if (sam == 0 && stp == 0 && max <= 10) printf("\e[1;32m%10d %10d %10d %10d %10d %10d %10d %10d %10d %10d\n", z_array[0], z_array[1], z_array[2], z_array[3], z_array[4], z_array[5], z_array[6], z_array[7], z_array[8], z_array[9]);

            total += end - start;
        }

        if (!best || total < best) {
            best = total;
        }
    }
    //printf("\e[0m  Quad Sort            : sorted %d elements in %f seconds. (%s)\n", max, best / 1000000.0, desc);

    for (cnt = 1; cnt < max; cnt++)
        if (z_array[cnt - 1] > z_array[cnt]) printf("        Quad Sort: not properly sorted at index %d. (%d vs %d\n", cnt, z_array[cnt - 1], z_array[cnt]);
	return best / 1000000.0;
}

float test_quick(int * z_array, int * r_array, int max, int rep, char * desc) {
    long long start, end, total, best;
    int cnt, sam, stp;

    best = 0;

    for (sam = 0; sam < 1; sam++) {
        total = 0;

        for (stp = 0; stp < rep; stp++) {
            memcpy(z_array, r_array, max * sizeof(int));

            if (sam == 0 && stp == 0 && max <= 10) printf("\e[1;31m%10d %10d %10d %10d %10d %10d %10d %10d %10d %10d\n", z_array[0], z_array[1], z_array[2], z_array[3], z_array[4], z_array[5], z_array[6], z_array[7], z_array[8], z_array[9]);

            start = utime();

            qsort(z_array, max, sizeof(int), cmp_int);

            end = utime();

            if (sam == 0 && stp == 0 && max <= 10) printf("\e[1;32m%10d %10d %10d %10d %10d %10d %10d %10d %10d %10d\n", z_array[0], z_array[1], z_array[2], z_array[3], z_array[4], z_array[5], z_array[6], z_array[7], z_array[8], z_array[9]);

            total += end - start;
        }

        if (!best || total < best) {
            best = total;
        }
    }
    //printf("\e[0m  Quick Sort           : sorted %d elements in %f seconds. (%s)\n", max, best / 1000000.0, desc);

    for (cnt = 1; cnt < max; cnt++)
        if (z_array[cnt - 1] > z_array[cnt]) printf("       Quick Sort: not properly sorted at index %d. (%d vs %d\n", cnt, z_array[cnt - 1], z_array[cnt]);
    return best / 1000000.0;
}

// 1=true, 0=false + added
int inBuffer(char* sort_buffer, char* sort) {
	char temp_sort[16];
	if(strstr(sort_buffer, sort) != NULL) {
		return 1;
	}
	else {
		strcat(sort_buffer, ",");
		strcat(sort_buffer, sort);
		return 0;
	}
}

// 1=true, 0=false
int sameOptions(int* sizes, int* sequence, int* prevSize, int* prevSeq) {
	for (int i = 0; i < 5; i++) {
		if (sizes[i] != prevSize[i]) {
			return 0;
		}
		if (sequence[i] != prevSeq[i]) {
			return 0;
		}
	}
	return 1;
}

#define SORT_TYPE int
#define SORT_CMP(x, y)  (x - y)
void cape_sort(SORT_TYPE *dst, const size_t size, FILE *dictionary) {
	printf("Cape Log:\n");
	double sampleStart = utime();
	/*---------* Sample the Data *---------*/
	
	int samples = size * 0.2; // Number of samples we need to take
	int window = 5; // The size of each window
	int groups = 4; // The number of windows we look at: samples / window (hardcoded)
	int increment = size / (groups + 1); // How far apart each window is (beginning to beginning)
	int cursor; // The int that will reference each point in a window, starts on first window
	
	char sampleSeq[groups]; // Asc: A, Des: D, Con: C, Ran: R
	int samCur = 0; // The cursor for moving through the sampleSeq array
	printf("Samples:\n");
	for (cursor = 0 - (int)(window/2) + increment; cursor + 5 < size; cursor += increment - window) {
		int comp[window-1]; // The amount of comparisons is 1 less than the amount in a window
		int asc = 0, des = 0, con = 0; // The amount of each comparison
		
		printf("[");
		for (int i = 0; i < window - 1; i++) { // Compare items in the window
			if (SORT_CMP(dst[cursor], dst[cursor+1]) < 0) { // Asc: 1
				asc++;
			}
			else if (SORT_CMP(dst[cursor], dst[cursor+1]) > 0) { // Des: 2
				des++;
			}
			else if (SORT_CMP(dst[cursor], dst[cursor+1]) == 0) { // Con: 3
				con++;
			}
			printf(" %d", dst[cursor]);
			cursor++;
		}
		printf(" %d ] ",  dst[cursor]);
		cursor++;
		
		if (asc == window-1) {
			sampleSeq[samCur++] = 'A';
			printf("Ascending\n");
		}
		else if (des == window-1) {
			sampleSeq[samCur++] = 'D';
			printf("Descending\n");
		}
		else if (con == window-1) {
			sampleSeq[samCur++] = 'C';
			printf("Constant\n");
		}
		else {
			sampleSeq[samCur++] = 'R';
			printf("Random\n");
		}
	}
	
	/**---------* Sample the Data *---------**/
	double sampleStop = utime();
	printf("Sample time:  %f\n", (sampleStop - sampleStart) / 1000000.0);
	double chooseStart = utime();
	/*---------* Search Dictionary  *---------*/
	
	rewind(dictionary);
	
	// Setting up buffer to read dictionary line by line
	int len = 255;
	char buffer[len+1];
	buffer[len] = '\0';
	
	// Skipping the first line (headers)
	fgets(buffer, len, dictionary);
	
	char sort[16]; // Name of sort
	while (fgets(buffer, len, dictionary) != NULL) {
		int z; // Cursor on line
		char dictSeq[4] = {0,0,0,0}; // Sequence of data types
		
		// Get the name of the sort
		for (z = 0; buffer[z] != ','; z++) {
			sort[z] = buffer[z];
		}
		sort[z++] = '\0';
		int y = 0;
		
		// Get the sequence
		int t;
		for (t = 0; buffer[z] != ','; t++) {
			dictSeq[t] = buffer[z++];
		}
		
/*		printf("\nDict Seq:");*/
/*		for (int i = 0; i < groups; i++) {*/
/*			printf(" %c", dictSeq[i]);*/
/*		}*/
/*		printf(", Sample Seq:");*/
/*		for (int i = 0; i < groups; i++) {*/
/*			printf(" %c", sampleSeq[i]);*/
/*		}*/
/*		printf("\n");*/
		
		// Check sequence
		for (int i = 0; i < groups; i++) {
			if (dictSeq[i] != sampleSeq[i]) { // Not a match
/*				printf("%d: Sequence not match\n\n", i);*/
				goto noMatch; // Next reference
			}
		}
		
		printf("Match Found\n");
		break; // Match found, moving on
		
		noMatch: // Not a match
		continue;
	}

	
	/**---------* Search Dictionary *---------**/
	double chooseStop = utime();
	printf("Choose time:  %f\n\nSort reads: %s\n", (chooseStop - chooseStart) / 1000000.0, sort);
	double runStart = utime();
	/*---------* Run Recommended Sort *---------*/
	
	if (strcmp(sort, "Quad") == 0) {
		printf("Chose Quad\n");
		quadsort(dst, size, sizeof(int), cmp_int);
	}
		
	else if (strcmp(sort, "Tim") == 0) {
		printf("Chose Tim\n");
		sorter_tim_sort(dst, size);
	}

	else if (strcmp(sort, "Quick") == 0) {
		printf("Chose Quick\n");
		qsort(dst, size, sizeof(int), cmp_int);
	}
		
	else if (strcmp(sort, "Selection") == 0) {
		printf("Chose Selection\n");
		sorter_selection_sort(dst, size);
	}
		
	else if (strcmp(sort, "Bubble") == 0) {
		printf("Chose Bubble\n");
		sorter_bubble_sort(dst, size);
	}
		
	else if (strcmp(sort, "Bitonic") == 0) {
		printf("Chose Bitonic\n");
		sorter_bitonic_sort(dst, size);
	}
		
	else if (strcmp(sort, "Merge") == 0) {
		printf("Chose Merge\n");
		sorter_merge_sort(dst, size);
	}
		
	else if (strcmp(sort, "BinaryInsertion") == 0) {
		printf("Chose BinaryInsertion\n");
		sorter_binary_insertion_sort(dst, size);
	}
		
	else if (strcmp(sort, "Heap") == 0) {
		printf("Chose Heap\n");
		sorter_heap_sort(dst, size);
	}
		
	else if (strcmp(sort, "Shell") == 0) {
		printf("Chose Shell\n");
		sorter_shell_sort(dst, size);
	}
		
	else if (strcmp(sort, "MergeInPlace") == 0) {
		printf("Chose MergeInPlace\n");
		sorter_merge_sort_in_place(dst, size);
	}
		
	else if (strcmp(sort, "Grail") == 0) {
		printf("Chose Grail\n");
		sorter_grail_sort(dst, size);
	}
		
	else if (strcmp(sort, "Sqrt") == 0) {
		printf("Chose Sqrt\n");
		sorter_sqrt_sort(dst, size);
	}
		
	else if (strcmp(sort, "RecStable") == 0) {
		printf("Chose RecStable\n");
		sorter_rec_stable_sort(dst, size);
	}
		
	else if (strcmp(sort, "GrailDyn") == 0) {
		printf("Chose GrailDyn\n");
		sorter_grail_sort_dyn_buffer(dst, size);
	}
		
	else if (strcmp(sort, "Shaker") == 0) {
		printf("Chose GrailDyn\n");
    	int i, j, k, m = size;
	    for (i = 0; i < m;) {
	        for (j = i + 1; j < m; j++) {
	            if (dst[j] < dst[j - 1])
	                swap( & dst[j], & dst[j - 1]);
	        }
	        m--;
	        for (k = m - 1; k > i; k--) {
	            if (dst[k] < dst[k - 1])
	                swap( & dst[k], & dst[k - 1]);
	        }
	        i++;
	    }
	}
	
	else {
		printf("Defaulted to Quad\n");
		quadsort(dst, size, sizeof(int), cmp_int);
	}
	
	/**---------* Run Recommended Sort *---------**/
	double runStop = utime();
	printf("Sorting time: %f\n\n", (runStop - runStart) / 1000000.0);
	/**---------* Stop Cape Sort *---------**/
}

float test_cape(int * z_array, int * r_array, int max, int rep, char * desc, FILE *dict) {
	double start;
    double end;
    double total = 0;

    for (int i = 0; i < rep; i++) {
        memcpy(z_array, r_array, max * sizeof(int));
        start = utime();
        cape_sort(z_array, max, dict);
        end = utime();
        total += end - start;
        verify(z_array, max);
    }

    //printf("\e[0m  Cape Sort            : sorted %d elements in %f seconds. (%s)\n", max, total / 1000000.0, desc);
    return total / 1000000.0;
}

void generate(int *arr, int datanumber, char unit, int parts, char *seq) {
	srand(time(0));
	// Varaible Defaults
	int max = 1;
	int random, num = rand() % 100;
	int n = 0;
	
	// Used to help with multiple type generation
	char choice = seq[0];
	char previous = choice;
	// For the length of the sequence
	for (int i = 0; i < parts; i++) {
		choice = seq[i];
		// Determining size for this part of the data
		if (choice != 0) {
			int datasize = 0;
			if (unit == 'k' || unit == 'K') {
				datasize = datanumber * 1024 / parts;
			}
			if (unit == 'm' || unit == 'M') {
				datasize = datanumber * 1024 * 1024 / parts;
			}
			if (unit == 'g' || unit == 'G') {
				datasize = datanumber * 1024 * 1024 * 1024 / parts;
			}
			if (datasize != 0) {
				max = datasize;
			} else {
				max = datanumber / parts;
			}
		}
		// Create data based on the part of the sequence
		switch (choice) {
		    case 'A':
		        //----------------------ascending
		        for (int i = 0; i < max; i++, n++) {
		            random = (rand() % (2 - 1 + 1)) + 1;
		            num += random;
		            arr[n] = num;
		        }
		        break;
		    
		    case 'D':
		        //--------------------------------descending
		        for (int i = 0; i < max; i++, n++) {
		            random = (rand() % (2 - 1 + 1)) + 1;
		            num -= random;
		            arr[n] = num;
		        }
		        break;
		    
		    case 'C':
		        //--------------------------------constant
		        for (int i = 0; i < max; i++, n++) {
		            arr[n] = num;
		        }
		        break;
			
			case 'R':
		        //--------------------------------random
		        for (int i = 0; i < max; i++, n++) {
		            random = (rand() % (2 - 1 + 1)) + 1;
		            if (i % 2) {
		                num += random;
		            } else {
		                num -= random;
		            }
		            arr[n] = num;
		        }
		        break;

		    case 0:
		    	return;
		        break;
		        
		    default:
		    	return;
		}
		// Increment to the next number in the sequence
		previous = choice;
    }
}

int increment(char *seq, int inc) {
	if (seq[inc] == 'A') {
		seq[inc] = 'D';
	}
	else if (seq[inc] == 'D') {
		seq[inc] = 'C';	
	}
	else if (seq[inc] == 'C') {
		seq[inc] = 'R';
	}
	else if (seq[inc] == 'R') {
		seq[inc] = 'A';
		increment(seq, inc-1);
	}
}

int generate_seqs(int parts, int amount, char seqs[amount+1][parts]) {
	char seq[parts];
	char ter[parts];
	int i;
	for (i = 0; i < parts; i++) {
		seq[i] = 'A';
	}
	seq[i] = '\0';
	
	for (i = 0; i < parts; i++) {
		ter[i] = 'R';
	}
	ter[i] = '\0';
/*	printf("%s %s\n", seq, ter);*/
	
	for (i = 0; i < parts; i++) {
		seqs[0][i] = seq[i];
	}
	
	for (i=1; strcmp(seq, ter) != 0; i++) {
		increment(seq, parts-1);
		for (int j = 0; j < parts; j++) {
			seqs[i][j] = seq[j];
		}
	}
}

int main(int argc, char **argv) {
/*	int datanumbers[8] = {128, 256, 512, 1, 2, 4, 8, 16};*/
/*	char units[8] = {'k', 'k', 'k', 'm', 'm', 'm', 'm', 'm'};*/
	
	int datanumbers[3] = {128, 256, 512};
	char units[3] = {'k', 'k', 'k'};
	
/*	int datanumbers[3] = {128, 256, 512};*/
/*	char units[3] = {'k', 'k', 'k'};*/
	
	for (int multiTest = 0; multiTest < (sizeof(datanumbers) / sizeof(int)); multiTest++) {
	int datanumber = datanumbers[multiTest];
	char unit = units[multiTest];
	/*---------* Get Data Size *---------*/
	/*---------* Data User Changes *---------*/
	
	int /*datanumber = 8, */repeat_times = 100, parts = 4;
/*	char unit = 'k';*/
	
/*	printf("Please enter the SIZE of data     -->  ");*/
/*    scanf("%d", & datanumber);*/
/*    printf("Enter the Units of data[K or M or N(no unit)]   -->  ");*/
/*    scanf(" %c", & unit);*/
/*	printf("Please enter the test repeat times     -->  ");*/
/*	scanf("%d", & repeat_times);*/
/*	printf("How many parts? ");*/
/*	scanf("%d", &parts);*/
	
	/**---------* Data User Changes *---------**/
	double start = utime();
	
	// Determining size of data and setting up arrays
	int datasize = 0;
	if (unit == 'k' || unit == 'K') {
        datasize = datanumber * 1024;
    }
    if (unit == 'm' || unit == 'M') {
        datasize = datanumber * 1024 * 1024;
    }
    if (unit == 'g' || unit == 'G') {
    	datasize = datanumber * 1024 * 1024 * 1024;
    }
	static int max;
	if (datasize != 0) {
	    max = datasize;
	} else {
	    max = datanumber;
	}
	
	int amount = 1;
	for (int i = 0; i < parts; i++) {
		amount *= 4;
	}
	
	/**---------* Get Data Size *---------**/
	/*---------* Read Testing Methods *---------*/
	
	double dictStart = utime();
	FILE *dictionary = fopen("CapeSort_Dictionary.csv", "r");
	if (dictionary == NULL) {
		printf("There was an error opening the dictionary.");
		exit(1);
	}
	double dictStop = utime();
	printf("Open Dictionary time:  %f\t\n", (dictStop - dictStart) / 1000000.0);
	
	FILE *sortFile = fopen("Sorts.csv", "r");
	if (sortFile == NULL) {
		printf("There was an error opening the csv.");
		exit(2);
	}
	
	if (stat("Times", &st) == -1) {
		mkdir("Times", 0777);
	}
	
	char fileName[31] = "Times/Sequence_Times_";
	char chNumber[5];
	snprintf(chNumber, sizeof chNumber, "%d", datanumber);
	char chUnit[2];
	snprintf(chUnit, sizeof chUnit, "%c", unit);
	strcat(fileName, chNumber);
	strcat(fileName, chUnit);
	strcat(fileName, ".csv");
	printf("%s\n", &fileName[6]);
	
	FILE *seqTimes = fopen(fileName, "w");
	if (dictionary == NULL) {
		printf("There was an error outputing the files.");
		exit(4);
	}
	fputs("Sorts,Sequence,Time,\n", seqTimes);
	printf("Opened file\n");
	
	int len = 255;
	char sorts[len+1];
	int i;
	for (i = 0; i < len+1; i++) {
		sorts[i] = '\0';
	}
	
	
	/**---------* Read Testing Methods *---------**/
	/*---------* Generate Sequences *---------*/
	
	char seqs[amount+1][parts];
	generate_seqs(parts, amount, seqs);
	fgets(sorts, len, sortFile);
	
	fclose(sortFile);
	
	/**---------* Generate Sequences *---------**/
	
	float tCape = 0.0, tQuad = 0.0, tQuick = 0.0, tTim = 0.0, tSelection = 0.0, tBubble = 0.0,
			tBitonic = 0.0, tMerge = 0.0, tBinIns = 0.0, tHeap = 0.0, tShell = 0.0,
			tMergeIn = 0.0, tGrail = 0.0, tSqrt = 0.0, tRecStable = 0.0, tGrailDyn = 0.0,
			tShaker = 0.0;
	/*---------* Test Sequences *---------*/
	for (int seqNum = 0; seqNum < amount; seqNum++) {
		/*---------* Test Sorts *---------*/
		float cape = 0.0, quad = 0.0, quick = 0.0, tim = 0.0, selection = 0.0, bubble = 0.0,
				bitonic = 0.0, merge = 0.0, binIns = 0.0, heap = 0.0, shell = 0.0,
				mergeIn = 0.0, grail = 0.0, sqrt = 0.0, recStable = 0.0, grailDyn = 0.0,
				shaker = 0.0;
				
		char seq[parts];
		for (int j = 0; j < parts; j++) {
			seq[j] = seqs[seqNum][j];
		}
		printf("%d: %s\n", seqNum+1, seq);
		
		/*---------* Generate Data *---------*/
		
		int * z_array, * r_array; // The arrays holding the data
		int rnd = 1;
		srand(rnd);

		z_array = malloc(max * sizeof(int)); // The array that will be sorted
		r_array = malloc(max * sizeof(int)); // The original data set
		
		generate(r_array, datanumber, unit, parts, seq);
		
/*			if (strstr(seq, "ACRD")) {*/
/*				printf("[%d", r_array[0]);*/
/*				for (int i = 1; i < max; i++) {*/
/*					printf(", %d", r_array[i]);*/
/*				}*/
/*				printf("]\n");*/
/*			}*/
		
		memcpy(z_array, r_array, max * sizeof(int));
		int rep = 1;
		
		/**---------* Generate Data *---------**/
		/*---------* Run Sorts *---------*/
		for (int i = 0; i < repeat_times; i++) {
			printf("About to Sort %s\nSorts: %s\n", seq, sorts);
			if (strstr(sorts, "Cape") != NULL) {
				cape  += test_cape(z_array, r_array, max, rep, "sheet order", dictionary);
			}
			
			if (strstr(sorts, "Quad") != NULL) {
				quad  += test_quad(z_array, r_array, max, rep, "sheet order");
			}

			if (strstr(sorts, "Quick") != NULL) {
				quick  += test_quick(z_array, r_array, max, rep, "sheet order");
			}
					
			if (strstr(sorts, "Tim") != NULL) {
				tim  += test_tim(z_array, r_array, max, rep, "sheet order");
			}
					
			if (strstr(sorts, "Selection") != NULL) {
				selection  += test_selection(z_array, r_array, max, rep, "sheet order");
			}
					
			if (strstr(sorts, "Bubble") != NULL) {
				bubble  += test_bubble(z_array, r_array, max, rep, "sheet order");
			}
					
			if (strstr(sorts, "Bitonic") != NULL) {
				bitonic  += test_bitonic(z_array, r_array, max, rep, "sheet order");
			}
					
			if (strstr(sorts, "Merge") != NULL) {
				merge  += test_merge(z_array, r_array, max, rep, "sheet order");
			}
					
			if (strstr(sorts, "BinaryInsertion") != NULL) {
				binIns  += test_binary_insertion(z_array, r_array, max, rep, "sheet order");
			}
					
			if (strstr(sorts, "Heap") != NULL) {
				heap  += test_heap(z_array, r_array, max, rep, "sheet order");
			}
					
			if (strstr(sorts, "Shell") != NULL) {
				shell  += test_shell(z_array, r_array, max, rep, "sheet order");
			}
					
			if (strstr(sorts, "MergeInPlace") != NULL) {
				mergeIn  += test_in_place_merge(z_array, r_array, max, rep, "sheet order");
			}
					
			if (strstr(sorts, "Grail") != NULL) {
				grail  += test_grail(z_array, r_array, max, rep, "sheet order");
			}
					
			if (strstr(sorts, "Sqrt") != NULL) {
				sqrt  += test_sqrt(z_array, r_array, max, rep, "sheet order");
			}
					
			if (strstr(sorts, "RecStable") != NULL) {
				recStable  += test_rec_stable(z_array, r_array, max, rep, "sheet order");
			}
					
			if (strstr(sorts, "GrailDyn") != NULL) {
				grailDyn  += test_grail_dyn_buffer(z_array, r_array, max, rep, "sheet order");
			}
					
			if (strstr(sorts, "Shaker") != NULL) {
				shaker  += test_Shaker(z_array, r_array, max, rep, "sheet order");
			}
			printf("\n\n");
		}
		/**---------* Run Sorts *---------**/
		// Free the arrays used from memory
		free(z_array);
		free(r_array);
		
/*		int temp;*/
/*		scanf("%d", &temp);*/
		
		/**---------* Test Sorts *---------**/
		/*---------* Write Averages *---------*/
		char buffer[len+1];
		
		for (int i = 0; i <= len; i++) {
			buffer[i] = '\0';
		}
		
/*		printf("Writing Averages\n");*/
		if (cape != 0.0) {
			tCape  += cape;
			cape /= ((float) repeat_times);
			strcat(buffer, "Cape,");
			strcat(buffer, seq);
			strcat(buffer, ",");
			
			char average[16];
			snprintf(average, sizeof average, "%f", cape);
			strcat(buffer, average);
			
			strcat(buffer, ",\n");
		}
		if (quad != 0.0) {
			tQuad  += quad;
			quad /= ((float) repeat_times);
			strcat(buffer, "Quad,");
			strcat(buffer, seq);
			strcat(buffer, ",");
			
			char average[16];
			snprintf(average, sizeof average, "%f", quad);
			strcat(buffer, average);
			
			strcat(buffer, ",\n");
		}
		if (quick != 0.0) {
			tQuick  += quick;
			quick /= ((float) repeat_times);
			strcat(buffer, "Quick,");
			strcat(buffer, seq);
			strcat(buffer, ",");
			
			char average[16];
			snprintf(average, sizeof average, "%f", quick);
			strcat(buffer, average);
			
			strcat(buffer, ",\n");
		}
		if (tim != 0.0) {
			tTim  += tim;
			tim /= ((float) repeat_times);
			strcat(buffer, "Tim,");
			strcat(buffer, seq);
			strcat(buffer, ",");
			
			char average[16];
			snprintf(average, sizeof average, "%f", tim);
			strcat(buffer, average);
			
			strcat(buffer, ",\n");
		}
		if (selection != 0.0) {
			tSelection  += selection;
			selection /= ((float) repeat_times);
			strcat(buffer, "Selection,");
			strcat(buffer, seq);
			strcat(buffer, ",");
			
			char average[16];
			snprintf(average, sizeof average, "%f", selection);
			strcat(buffer, average);
			
			strcat(buffer, ",\n");
		}
		if (bubble != 0.0) {
			tBubble  += bubble;
			bubble /= ((float) repeat_times);
			strcat(buffer, "Bubble,");
			strcat(buffer, seq);
			strcat(buffer, ",");
			
			char average[16];
			snprintf(average, sizeof average, "%f", bubble);
			strcat(buffer, average);
			
			strcat(buffer, ",\n");
		}
		if (bitonic != 0.0) {
			tBitonic  += bitonic;
			bitonic /= ((float) repeat_times);
			strcat(buffer, "Bitonic,");
			strcat(buffer, seq);
			strcat(buffer, ",");
			
			char average[16];
			snprintf(average, sizeof average, "%f", bitonic);
			strcat(buffer, average);
			
			strcat(buffer, ",\n");
		}
		if (merge != 0.0) {
			tMerge  += merge;
			merge /= ((float) repeat_times);
			strcat(buffer, "Merge,");
			strcat(buffer, seq);
			strcat(buffer, ",");
			
			char average[16];
			snprintf(average, sizeof average, "%f", merge);
			strcat(buffer, average);
			
			strcat(buffer, ",\n");
		}
		if (binIns != 0.0) {
			tBinIns  += binIns;
			binIns /= ((float) repeat_times);
			strcat(buffer, "Binary Insert,");
			strcat(buffer, seq);
			strcat(buffer, ",");
			
			char average[16];
			snprintf(average, sizeof average, "%f", binIns);
			strcat(buffer, average);
			
			strcat(buffer, ",\n");
		}
		if (heap != 0.0) {
			tHeap  += heap;
			heap /= ((float) repeat_times);
			strcat(buffer, "Heap,");
			strcat(buffer, seq);
			strcat(buffer, ",");
			
			char average[16];
			snprintf(average, sizeof average, "%f", heap);
			strcat(buffer, average);
			
			strcat(buffer, ",\n");
		}
		if (shell != 0.0) {
			tShell  += shell;
			shell /= ((float) repeat_times);
			strcat(buffer, "Shell,");
			strcat(buffer, seq);
			strcat(buffer, ",");
			
			char average[16];
			snprintf(average, sizeof average, "%f", shell);
			strcat(buffer, average);
			
			strcat(buffer, ",\n");
		}
		if (mergeIn != 0.0) {
			tMergeIn  += mergeIn;
			mergeIn /= ((float) repeat_times);
			strcat(buffer, "Merge In Place,");
			strcat(buffer, seq);
			strcat(buffer, ",");
			
			char average[16];
			snprintf(average, sizeof average, "%f", mergeIn);
			strcat(buffer, average);
			
			strcat(buffer, ",\n");
		}
		if (grail != 0.0) {
			tGrail  += grail;
			grail /= ((float) repeat_times);
			strcat(buffer, "Grail,");
			strcat(buffer, seq);
			strcat(buffer, ",");
			
			char average[16];
			snprintf(average, sizeof average, "%f", grail);
			strcat(buffer, average);
			
			strcat(buffer, ",\n");
		}
		if (sqrt != 0.0) {
			tSqrt  += sqrt;
			sqrt /= ((float) repeat_times);
			strcat(buffer, "Sqrt,");
			strcat(buffer, seq);
			strcat(buffer, ",");
			
			char average[16];
			snprintf(average, sizeof average, "%f", sqrt);
			strcat(buffer, average);
			
			strcat(buffer, ",\n");
		}
		if (recStable != 0.0) {
			tRecStable  += recStable;
			recStable /= ((float) repeat_times);
			strcat(buffer, "RecStable,");
			strcat(buffer, seq);
			strcat(buffer, ",");
			
			char average[16];
			snprintf(average, sizeof average, "%f", recStable);
			strcat(buffer, average);
			
			strcat(buffer, ",\n");
		}
		if (grailDyn != 0.0) {
			tGrailDyn  += grailDyn;
			grailDyn /= ((float) repeat_times);
			strcat(buffer, "GrailDyn,");
			strcat(buffer, seq);
			strcat(buffer, ",");
			
			char average[16];
			snprintf(average, sizeof average, "%f", grailDyn);
			strcat(buffer, average);
			
			strcat(buffer, ",\n");
		}
		if (shaker != 0.0) {
			tShaker  += shaker;
			shaker /= ((float) repeat_times);
			strcat(buffer, "Shaker,");
			strcat(buffer, seq);
			strcat(buffer, ",");
			
			char average[16];
			snprintf(average, sizeof average, "%f", shaker);
			strcat(buffer, average);
			
			strcat(buffer, ",\n");
		}
		
/*		printf("Writing Buffer\n\n");*/

		// Write the buffer to the new document
		fputs(buffer, seqTimes);
/*		printf("Done Writing Buffer\n\n");*/
		
		/**---------* Write Averages *---------**/
	}
	/**---------* Test Sequences *---------**/
	/*---------* Print Totals *---------*/
	if (tCape != 0.0) {
		printf("Cape total: %0.6f\n", tCape);
	}
	if (tQuad != 0.0) {
		printf("Quad total: %0.6f\n", tQuad);
	}
	if (tQuick != 0.0) {
		printf("Quick total: %0.6f\n", tQuick);
	}
	if (tTim != 0.0) {
		printf("Tim total: %0.6f\n", tTim);
	}
	if (tSelection != 0.0) {
		printf("Selection total: %0.6f\n", tSelection);
	}
	if (tBubble != 0.0) {
		printf("Bubble total: %0.6f\n", tBubble);
	}
	if (tBitonic != 0.0) {
		printf("Bitonic total: %0.6f\n", tBitonic);
	}
	if (tMerge != 0.0) {
		printf("Merge total: %0.6f\n", tMerge);
	}
	if (tBinIns != 0.0) {
		printf("BinIns total: %0.6f\n", tBinIns);
	}
	if (tHeap != 0.0) {
		printf("Heap total: %0.6f\n", tHeap);
	}
	if (tShell != 0.0) {
		printf("Shell total: %0.6f\n", tShell);
	}
	if (tMergeIn != 0.0) {
		printf("MergeIn total: %0.6f\n", tMergeIn);
	}
	if (tGrail != 0.0) {
		printf("Grail total: %0.6f\n", tGrail);
	}
	if (tSqrt != 0.0) {
		printf("Sqrt total: %0.6f\n", tSqrt);
	}
	if (tRecStable != 0.0) {
		printf("RecStable total: %0.6f\n", tRecStable);
	}
	if (tGrailDyn != 0.0) {
		printf("GrailDyn total: %0.6f\n", tGrailDyn);
	}
	if (tShaker != 0.0) {
		printf("Shaker total: %0.6f\n", tShaker);
	}
	/**---------* Print Totals *---------**/
	/*---------* Close Out Program *---------*/
	
	// Close the open csv file
	fclose(dictionary);
	fclose(seqTimes);
	
	// Stop the timer
	double end = utime();
	double total = (end - start) / 1000000.0;
	
	char closeName[28] = "Times/TestComplete_";
	strcat(closeName, chNumber);
	strcat(closeName, chUnit);
	strcat(closeName, ".txt");
	printf("\n%s\n", closeName);
	FILE *done = fopen(closeName, "w+");
	
	// Print the time on timer
	printf("Task completion time:");
	fprintf(done, "Task completion time:");
	int hours = total/3600;
	int minutes = total/60 - hours*60;
	float seconds = total - minutes*60 - hours*3600;
	if (hours > 0) {
		if (hours > 1) {
			printf(" %d hours", hours);
			fprintf(done, " %d hours", hours);
		}
		else {
			printf(" %d hour", hours);
			fprintf(done, " %d hour", hours);
		}
	}
	if (minutes > 0) {
		if (minutes > 1) {
			printf(" %d minutes", minutes);
			fprintf(done, " %d minutes", minutes);
		}
		else {
			printf(" %d minute", minutes);
			fprintf(done, " %d minute", minutes);
		}
	}
	printf(" %f seconds\n", seconds);
	fprintf(done, " %f seconds\n", seconds);
	
	fclose(done);
	} // This closes the multiTest loop
    return 0;
	
	/**---------* Close Out Program *---------**/
}
